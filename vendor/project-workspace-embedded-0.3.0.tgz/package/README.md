# Project Workspace

A standalone Next.js service that turns GitHub repositories into clean, live Markdown workspaces without cloning repositories.

To add this as a page inside an existing Next.js SaaS using its own login, run the setup command from that SaaS repository after publishing the package to your npm registry:

```bash
npx --yes @project-workspace/embedded init --auth-module src/auth.ts --yes
```

The command installs the package, adds `/workspace` and its API route, and connects both to your existing server-side `auth()` function. Pass `--auth-export getSession` if your function has a different name. For shared organization workspaces, pass `--tenant-id user.orgId --manage-path user.isAdmin`; adjust the session field paths to match your SaaS. The package is not yet published, so see [INTEGRATION.md](INTEGRATION.md) for a local tarball command, publishing, other options, and the manual React/Express setup.

## How it works

1. A user enters an HTTPS GitHub repository URL—or a `/tree/branch/folder` URL—and a fine-grained, read-only access token.
2. The backend validates that token, encrypts it, and reads repository metadata, the file tree, and selected blobs through GitHub REST APIs.
3. `README.md` becomes the home document and other Markdown files form the navigation tree.
4. Content is cached in memory by commit SHA and rendered safely in the browser.
5. The service checks the default branch periodically. A signed GitHub push webhook can update it immediately.

No repository working copy is created on the user device or service filesystem. Registration metadata, encrypted credentials, and a content-addressed API cache are stored under `.data`; the cache contains no `.git` directory and remains usable during temporary GitHub rate limits or outages.

Folder URLs create scoped workspaces. For example, `https://github.com/company/project/tree/main/docs` shows only files inside `docs`, with paths relative to that folder. The selected branch and folder remain attached to automatic sync and push-webhook updates.

## Features

- Multiple public or private GitHub repositories.
- GitHub-style Markdown, tables, checklists, code highlighting, relative links, images, PDFs, fenced Mermaid blocks, and standalone `.mmd`/`.mermaid` diagrams.
- Manual **Sync**, automatic polling, signed webhooks, and live browser refresh through SSE.
- Commit-pinned reads so the tree and document content stay consistent during updates.
- Persistent API cache so previously loaded documentation remains available when GitHub is temporarily unavailable.
- Per-repository GitHub credentials, path validation, file-size limits, and sanitized Markdown output.
- AES-256-GCM encrypted token storage; tokens are never returned by the API or browser.
- GitHub App installation authentication and `GITHUB_TOKEN` remain available as service-level fallbacks for migrated registrations.

## Run locally

Requirements: Node.js 20 or newer. Git is not required.

```bash
npm install
npm run dev
```

Open `http://127.0.0.1:3000`, click **Add repository**, and enter a URL such as:

```text
https://github.com/tintiatekaushik-spec/md-test
```

Create a fine-grained GitHub token for that repository with **Contents: read-only** permission and paste it into the password-style token field. Each repository uses its own GitHub quota. Existing registrations can receive a token from the repository menu using **Update access token**.

For local use, the service generates `.data/token-encryption.key` automatically. For a deployed service, set `PROJECT_WORKSPACE_TOKEN_ENCRYPTION_KEY` to a stable 32-byte secret (64 hexadecimal characters or base64) in the deployment secret manager. The legacy `TOKEN_ENCRYPTION_KEY` name is also accepted. Losing or changing this key makes stored tokens unreadable.

## Production authentication

Per-repository fine-grained tokens are the implemented internal-company flow. They make onboarding simple: the user supplies the URL and token, the service validates access, and no cloning or local Git setup is needed.

For a larger multi-tenant SaaS, the recommended next step is a GitHub App with **Contents: read-only** access:

```env
GITHUB_APP_ID=123456
GITHUB_APP_PRIVATE_KEY="-----BEGIN PRIVATE KEY-----\n...\n-----END PRIVATE KEY-----"
```

Install the app only on repositories the service may read. Project Workspace can discover the installation for previously registered repositories and use short-lived installation tokens. The current add-repository screen intentionally requires a per-repository token for the internal deployment.

For instant updates, set a webhook URL to `https://your-service.example/api/github/webhook`, subscribe to **Push**, and configure the same secret on both sides:

```env
GITHUB_WEBHOOK_SECRET=generate_a_long_random_secret
```

Without a webhook, automatic polling and the **Sync** button still work.

## Production build

```bash
npm run build
npm start
```

## Quality checks

```bash
npm run check
npm test
npm run test:service
npm run test:ui
```

The integration tests run against an isolated mock GitHub API and verify that no repository clone or working directory is created.

Before exposing this service publicly, add company authentication, tenant authorization, a shared database/cache, rate limiting, and audit logs. The GitHub access layer is already isolated so PostgreSQL/Redis can replace local registration and in-memory content caches without changing the UI contract.
