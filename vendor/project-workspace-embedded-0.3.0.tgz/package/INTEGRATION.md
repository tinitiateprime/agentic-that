# Embed Project Workspace in a SaaS

The package exposes a React page and a Node.js API handler. The SaaS owns login,
roles, and the page URL. Project Workspace reads the identity returned by the
SaaS and stores each tenant's repositories, encrypted tokens, and cache in a
separate directory.

## One-command setup for a Next.js SaaS

Publish this package to a private npm registry under a scope you own. Then, from
the root of each **npm-based Next.js App Router** SaaS, run:

```bash
npx --yes @project-workspace/embedded init --auth-module src/auth.ts --yes
```

`src/auth.ts` must export a server-side `auth()` function that reads the SaaS's
existing login session. The command installs the package, adds `/workspace` and
`/api/project-workspace`, imports the stylesheet, and generates a small adapter
that reads `session.user.id`. Signed-out users are redirected to `/login`; the
API also rejects them. Each user gets a private workspace by default. The
command creates a random local encryption key in `.env.local` and ignores that
file plus workspace data in Git.

For a shared organization workspace with restricted repository management:

```bash
npx --yes @project-workspace/embedded init --auth-module src/auth.ts --tenant-id user.orgId --manage-path user.isAdmin --yes
```

The session field paths are examples; use the paths your SaaS session actually
returns. Add `--auth-export getSession` when your exported function is named
`getSession`, `--user-id id` when the user ID is at `session.id`, or
`--route tools/workspace` to choose another page URL. Run
`npx --yes @project-workspace/embedded --help` for all options. The installer checks
for existing target files and refuses to overwrite them. It supports `app/` and
`src/app/`, TypeScript and JavaScript layouts, and npm. The generated auth
adapter is the one place to edit if your session shape needs more than a field
path.

The npm package is **not yet published**. Until you publish it, use the local
tarball workflow below. Publishing to a private registry requires registry
access in each SaaS build environment. The package name in the commands is the
current name; change it if your registry scope differs.

## Build and install locally

Run in this repository:

```bash
npm ci
npm run build:package
npm pack
```

The tarball is named `project-workspace-embedded-0.3.0.tgz`. In each SaaS
repository, run the packaged CLI with that tarball and tell it to install the
same tarball:

```bash
npm exec --yes --package=/absolute/path/to/project-workspace/project-workspace-embedded-0.3.0.tgz -- project-workspace init --auth-module src/auth.ts --package /absolute/path/to/project-workspace/project-workspace-embedded-0.3.0.tgz --yes
```

The tarball path must be reachable when each SaaS runs `npm install`; for
repeated deployments, a private npm registry is easier. Use `npm publish` from
this repository only after configuring a package scope and registry you own.

## Next.js App Router

This example assumes your SaaS has a server-side `getSession()` function.
Replace that import and the session fields with your existing authentication
system. The same session must be used by the page and API route.

Import the package stylesheet once from the SaaS `app/layout.tsx`:

```tsx
import "@project-workspace/embedded/styles.css";
```

Create `app/workspace/page.tsx`:

```tsx
import { redirect } from "next/navigation";
import { ProjectWorkspacePage } from "@project-workspace/embedded/react";
import { getSession } from "@/lib/auth";

export const dynamic = "force-dynamic";

export default async function WorkspacePage() {
  const session = await getSession();
  if (!session) redirect("/login");

  return (
    <ProjectWorkspacePage
      apiBasePath="/api/project-workspace"
      storageKey={`workspace:${session.tenantId}:${session.userId}`}
      canManageRepositories={session.canManageRepositories}
    />
  );
}
```

Create `app/api/project-workspace/[[...path]]/route.ts`:

```ts
import path from "node:path";
import { createProjectWorkspaceHandler } from "@project-workspace/embedded/server";
import { getSession } from "@/lib/auth";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const handler = createProjectWorkspaceHandler({
  apiBasePath: "/api/project-workspace",
  dataDirectory: process.env.PROJECT_WORKSPACE_DATA_DIR
    || path.join(process.cwd(), ".data", "project-workspace"),
  getIdentity: async () => {
    const session = await getSession();
    if (!session) return null;
    return {
      userId: session.userId,
      tenantId: session.tenantId,
      canManageRepositories: session.canManageRepositories,
    };
  },
});

export { handler as GET, handler as POST, handler as PUT, handler as DELETE };
```

The tenant ID comes from the verified SaaS session. Do not accept it from a
query string, request body, or browser header. The server enforces
`canManageRepositories` for adding or removing repositories and changing
GitHub tokens. Pass the same permission to the React page to show the matching
controls.

For immediate GitHub push updates, add `webhook` to the handler options:

```ts
webhook: {
  secret: process.env.GITHUB_WEBHOOK_SECRET!,
  tenantIdsForRepository: async (fullName) =>
    yourSaasDatabase.findTenantIdsForGitHubRepository(fullName),
},
```

Point the GitHub **Push** webhook at
`https://your-saas.example/api/project-workspace/github/webhook` and use the
same secret on both sides. This endpoint accepts signed GitHub requests
without a SaaS login; all other API routes require the host session. The SaaS
lookup must return tenant IDs that have registered that repository. Browser
polling and the **Sync** button work without a webhook.

## React with an Express API

Import the stylesheet in the React app and render the page on your chosen
authenticated route:

```tsx
import "@project-workspace/embedded/styles.css";
import { ProjectWorkspacePage } from "@project-workspace/embedded/react";

export function WorkspaceRoute({ session }: { session: {
  tenantId: string;
  userId: string;
  canManageRepositories: boolean;
} }) {
  return (
    <ProjectWorkspacePage
      storageKey={`workspace:${session.tenantId}:${session.userId}`}
      canManageRepositories={session.canManageRepositories}
    />
  );
}
```

Mount the API **after** your SaaS's session middleware:

```ts
import path from "node:path";
import { createProjectWorkspaceExpressRouter } from "@project-workspace/embedded/express";

app.use("/api/project-workspace", createProjectWorkspaceExpressRouter({
  dataDirectory: path.join(process.cwd(), ".data", "project-workspace"),
  getIdentity: (request) => {
    const user = request.user; // From your existing login middleware.
    if (!user) return null;
    return {
      userId: user.id,
      tenantId: user.tenantId,
      canManageRepositories: user.canManageRepositories,
    };
  },
}));
```

If TLS terminates at a reverse proxy, configure Express `trust proxy` for
that trusted proxy so same-origin checks see the public HTTPS origin. Keep
the page and API on the same site so browser session cookies are sent to both.
If you enable GitHub webhooks, mount this router before any global JSON body
parser, or have that parser attach the original request bytes as
`request.rawBody`; webhook signature verification requires those exact bytes.

## Runtime and data

- Requires Node.js 20.9 or newer and a persistent, private data directory.
- Set a stable `PROJECT_WORKSPACE_TOKEN_ENCRYPTION_KEY` (32 bytes as 64 hex characters or base64)
  in the server's secret manager. The key must survive deploys so stored
  GitHub tokens remain readable.
- The included file store is intended for a **single Node.js process per SaaS
  deployment**. Serverless functions, multiple replicas, and shared database
  deployments need a storage adapter before production use.
- The package scopes its CSS to the workspace root. Set
  `--pw-top-offset` on an ancestor if your SaaS has a fixed header.
- The embedded page checks GitHub every five minutes while open. A manual
  **Sync** button is also available. On a long-running Node server, set
  `liveEvents` on the page to receive same-tenant server events.
- Each connected GitHub repository still needs a fine-grained token with
  **Contents: read-only** access.

The local standalone app (`npm run dev`) remains available for development.
