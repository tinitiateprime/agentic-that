"use client";
import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { BookOpen, CheckCircle2, FileText, FolderKanban, KeyRound, Menu, Moon, MoreHorizontal, Plus, RefreshCw, Search, Sun, Trash2, Wifi, WifiOff, Workflow, X, } from "lucide-react";
import { createWorkspaceApi } from "./api.js";
import { AddRepositoryDialog } from "./components/AddRepositoryDialog.js";
import { Brand } from "./components/Brand.js";
import { FileTree } from "./components/FileTree.js";
import { MarkdownPreview } from "./components/MarkdownPreview.js";
import { MermaidDocumentPreview } from "./components/MermaidDocumentPreview.js";
function flattenFiles(nodes) {
    return nodes.flatMap((node) => node.type === "file" ? [node] : flattenFiles(node.children || []));
}
function getInitialTheme(storageKey) {
    if (typeof window === "undefined")
        return "light";
    const stored = localStorage.getItem(`${storageKey}-theme`);
    if (stored === "light" || stored === "dark")
        return stored;
    return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}
function formatDate(value) {
    return new Intl.DateTimeFormat(undefined, {
        month: "short",
        day: "numeric",
        hour: "numeric",
        minute: "2-digit",
    }).format(new Date(value));
}
function App({ apiBasePath = "/api", storageKey = "project-workspace", canManageRepositories = true, liveEvents = true, pollIntervalMs = 0, className = "", }) {
    const api = useMemo(() => createWorkspaceApi(apiBasePath), [apiBasePath]);
    const [repositories, setRepositories] = useState([]);
    const [activeRepositoryId, setActiveRepositoryId] = useState(null);
    const [files, setFiles] = useState([]);
    const [activePath, setActivePath] = useState(null);
    const [document, setDocument] = useState(null);
    const [query, setQuery] = useState("");
    const [theme, setTheme] = useState("light");
    const [connection, setConnection] = useState("connecting");
    const [loadingRepositories, setLoadingRepositories] = useState(true);
    const [loadingDocument, setLoadingDocument] = useState(false);
    const [syncing, setSyncing] = useState(false);
    const [error, setError] = useState("");
    const [addDialogOpen, setAddDialogOpen] = useState(false);
    const [credentialRepository, setCredentialRepository] = useState(null);
    const [sidebarOpen, setSidebarOpen] = useState(false);
    const [repoMenuOpen, setRepoMenuOpen] = useState(false);
    const refreshTimer = useRef(undefined);
    const themeEffectReady = useRef(false);
    const activeRepositoryIdRef = useRef(null);
    const activePathRef = useRef(null);
    const activeRepository = useMemo(() => repositories.find((repository) => repository.id === activeRepositoryId) || null, [activeRepositoryId, repositories]);
    const activeDocumentIsMermaid = Boolean(document && (document.kind === "mermaid" || /\.(?:mmd|mermaid)$/i.test(document.path)));
    useEffect(() => {
        setTheme(getInitialTheme(storageKey));
    }, [storageKey]);
    useEffect(() => {
        activeRepositoryIdRef.current = activeRepositoryId;
    }, [activeRepositoryId]);
    useEffect(() => {
        activePathRef.current = activePath;
    }, [activePath]);
    const loadRepositories = useCallback(async (preferredId) => {
        const result = await api.repositories();
        setRepositories(result.repositories);
        setLoadingRepositories(false);
        const storedId = localStorage.getItem(`${storageKey}-repository`);
        const nextId = preferredId || storedId || result.repositories[0]?.id || null;
        const validId = result.repositories.some((repository) => repository.id === nextId)
            ? nextId
            : result.repositories[0]?.id || null;
        setActiveRepositoryId((current) => result.repositories.some((repository) => repository.id === current) ? current : validId);
        return result.repositories;
    }, [api, storageKey]);
    const loadDocument = useCallback(async (repositoryId, path, quiet = false) => {
        if (!quiet)
            setLoadingDocument(true);
        setError("");
        try {
            const result = await api.document(repositoryId, path);
            setDocument(result);
            setActivePath(path);
            activePathRef.current = path;
            localStorage.setItem(`${storageKey}-file:${repositoryId}`, path);
        }
        catch (loadError) {
            setError(loadError instanceof Error ? loadError.message : "Could not load document.");
            setDocument(null);
        }
        finally {
            setLoadingDocument(false);
        }
    }, [api, storageKey]);
    const loadFiles = useCallback(async (repositoryId, preserveSelection = true) => {
        try {
            const result = await api.files(repositoryId);
            setFiles(result.nodes);
            const flatFiles = flattenFiles(result.nodes);
            const remembered = preserveSelection
                ? activePathRef.current || localStorage.getItem(`${storageKey}-file:${repositoryId}`)
                : null;
            const nextFile = flatFiles.find((file) => file.path === remembered) ||
                flatFiles.find((file) => file.path.toLowerCase() === "readme.md") ||
                flatFiles.find((file) => file.isReadme) ||
                flatFiles[0];
            if (nextFile) {
                await loadDocument(repositoryId, nextFile.path);
            }
            else {
                setActivePath(null);
                setDocument(null);
            }
        }
        catch (loadError) {
            setFiles([]);
            setDocument(null);
            setError(loadError instanceof Error ? loadError.message : "Could not read repository.");
        }
    }, [api, loadDocument, storageKey]);
    useEffect(() => {
        setRepositories([]);
        setActiveRepositoryId(null);
        setFiles([]);
        setDocument(null);
        setLoadingRepositories(true);
        setError("");
        void loadRepositories().catch((loadError) => {
            setLoadingRepositories(false);
            setError(loadError instanceof Error ? loadError.message : "Could not connect to the service.");
        });
    }, [loadRepositories]);
    useEffect(() => {
        if (!activeRepositoryId) {
            setFiles([]);
            setDocument(null);
            return;
        }
        activeRepositoryIdRef.current = activeRepositoryId;
        localStorage.setItem(`${storageKey}-repository`, activeRepositoryId);
        setActivePath(null);
        activePathRef.current = null;
        setDocument(null);
        setQuery("");
        void loadFiles(activeRepositoryId, true);
    }, [activeRepositoryId, loadFiles, storageKey]);
    useEffect(() => {
        if (!themeEffectReady.current) {
            themeEffectReady.current = true;
            return;
        }
        localStorage.setItem(`${storageKey}-theme`, theme);
    }, [storageKey, theme]);
    useEffect(() => {
        if (!liveEvents) {
            setConnection("connected");
            return;
        }
        const events = new EventSource(api.events());
        events.onopen = () => setConnection("connected");
        events.onerror = () => setConnection("disconnected");
        events.onmessage = (event) => {
            const message = JSON.parse(event.data);
            if (message.repositoryId !== activeRepositoryIdRef.current)
                return;
            if (message.type === "repository-sync-error") {
                setError(message.message || "Could not sync the GitHub repository.");
                return;
            }
            if (message.type !== "repository-changed")
                return;
            window.clearTimeout(refreshTimer.current);
            refreshTimer.current = window.setTimeout(() => {
                const repositoryId = activeRepositoryIdRef.current;
                if (!repositoryId)
                    return;
                void loadFiles(repositoryId, true);
                void loadRepositories();
            }, 180);
        };
        return () => {
            window.clearTimeout(refreshTimer.current);
            events.close();
        };
    }, [api, liveEvents, loadFiles, loadRepositories]);
    useEffect(() => {
        if (pollIntervalMs <= 0)
            return;
        const timer = window.setInterval(() => {
            const repositoryId = activeRepositoryIdRef.current;
            if (!repositoryId)
                return;
            void api.syncRepository(repositoryId).then((result) => {
                if (result.changed) {
                    void loadFiles(repositoryId, true);
                    void loadRepositories();
                }
            }).catch((syncError) => {
                setError(syncError instanceof Error ? syncError.message : "Could not sync repository.");
            });
        }, Math.max(30_000, pollIntervalMs));
        return () => window.clearInterval(timer);
    }, [api, loadFiles, loadRepositories, pollIntervalMs]);
    const selectRepository = (id) => {
        if (id === activeRepositoryId)
            return;
        setActiveRepositoryId(id);
        setSidebarOpen(false);
        setRepoMenuOpen(false);
    };
    const openAddRepository = () => {
        setCredentialRepository(null);
        setAddDialogOpen(true);
    };
    const openCredentialUpdate = () => {
        if (!activeRepository)
            return;
        setCredentialRepository(activeRepository);
        setAddDialogOpen(true);
        setRepoMenuOpen(false);
    };
    const selectDocument = useCallback((path) => {
        if (!activeRepositoryId)
            return;
        void loadDocument(activeRepositoryId, path);
        setSidebarOpen(false);
    }, [activeRepositoryId, loadDocument]);
    const refresh = async () => {
        if (!activeRepositoryId)
            return;
        setSyncing(true);
        setError("");
        try {
            await api.syncRepository(activeRepositoryId);
            await Promise.all([loadRepositories(), loadFiles(activeRepositoryId, true)]);
        }
        catch (syncError) {
            setError(syncError instanceof Error ? syncError.message : "Could not sync repository.");
        }
        finally {
            setSyncing(false);
        }
    };
    const removeRepository = async () => {
        if (!activeRepository)
            return;
        const confirmed = window.confirm(`Remove “${activeRepository.name}” from Project Workspace? The GitHub repository will not be changed.`);
        if (!confirmed)
            return;
        await api.removeRepository(activeRepository.id);
        setRepoMenuOpen(false);
        setActiveRepositoryId(null);
        activeRepositoryIdRef.current = null;
        localStorage.removeItem(`${storageKey}-repository`);
        const nextRepositories = await loadRepositories();
        setActiveRepositoryId(nextRepositories[0]?.id || null);
    };
    return (_jsxs("div", { className: `pw-root app-shell ${className}`.trim(), "data-theme": theme, children: [_jsxs("aside", { className: `sidebar ${sidebarOpen ? "open" : ""}`, children: [_jsxs("div", { className: "sidebar-header", children: [_jsx(Brand, {}), _jsx("button", { className: "icon-button mobile-close", onClick: () => setSidebarOpen(false), "aria-label": "Close navigation", children: _jsx(X, { size: 19 }) })] }), _jsxs("div", { className: "sidebar-scroll", children: [_jsxs("section", { className: "sidebar-section repositories-section", children: [_jsxs("div", { className: "section-heading", children: [_jsx("span", { children: "Repositories" }), canManageRepositories && _jsx("button", { className: "mini-icon-button", onClick: openAddRepository, "aria-label": "Add repository", children: _jsx(Plus, { size: 16 }) })] }), loadingRepositories ? (_jsxs("div", { className: "repository-skeleton", children: [_jsx("span", {}), _jsx("span", {})] })) : repositories.length ? (_jsx("div", { className: "repository-list", children: repositories.map((repository) => (_jsxs("button", { className: `repository-row ${repository.id === activeRepositoryId ? "active" : ""}`, onClick: () => selectRepository(repository.id), children: [_jsx("span", { className: "repository-icon", children: _jsx(FolderKanban, { size: 17 }) }), _jsxs("span", { className: "repository-copy", children: [_jsx("strong", { children: repository.name }), _jsx("small", { children: repository.available
                                                                ? `${repository.fileCount} document${repository.fileCount === 1 ? "" : "s"}${repository.authenticated ? "" : " · cached"}`
                                                                : repository.authenticated
                                                                    ? "Repository unavailable"
                                                                    : "Access token required" })] }), repository.id === activeRepositoryId && _jsx("span", { className: "active-dot" })] }, repository.id))) })) : (canManageRepositories ? _jsxs("button", { className: "empty-repository-button", onClick: openAddRepository, children: [_jsx(Plus, { size: 16 }), " Add your first repository"] }) : _jsx("p", { className: "readonly-hint", children: "No repositories have been connected yet." }))] }), activeRepository && (_jsxs("section", { className: "sidebar-section documents-section", children: [_jsxs("div", { className: "section-heading documents-heading", children: [_jsx("span", { children: "Documents" }), _jsx("span", { className: "count-badge", children: activeRepository.fileCount })] }), _jsxs("label", { className: "search-field", children: [_jsx(Search, { size: 15 }), _jsx("input", { value: query, onChange: (event) => setQuery(event.target.value), placeholder: "Find a document\u2026" }), query && _jsx("button", { onClick: () => setQuery(""), "aria-label": "Clear search", children: _jsx(X, { size: 14 }) })] }), _jsx(FileTree, { nodes: files, activePath: activePath, query: query, onSelect: selectDocument })] }))] }), _jsxs("footer", { className: "sidebar-footer", children: [_jsxs("div", { className: `connection-status ${connection}`, children: [connection === "connected" ? _jsx(Wifi, { size: 14 }) : _jsx(WifiOff, { size: 14 }), _jsx("span", { children: !liveEvents ? (pollIntervalMs > 0 ? "Auto sync on" : "Manual sync") : connection === "connected" ? "GitHub sync on" : connection === "connecting" ? "Connecting…" : "Reconnecting…" })] }), _jsx("button", { className: "theme-toggle", onClick: () => setTheme(theme === "light" ? "dark" : "light"), "aria-label": `Use ${theme === "light" ? "dark" : "light"} theme`, children: theme === "light" ? _jsx(Moon, { size: 16 }) : _jsx(Sun, { size: 16 }) })] })] }), sidebarOpen && _jsx("button", { className: "sidebar-scrim", onClick: () => setSidebarOpen(false), "aria-label": "Close navigation" }), _jsxs("main", { className: "workspace", children: [_jsxs("header", { className: "workspace-header", children: [_jsxs("div", { className: "document-location", children: [_jsx("button", { className: "icon-button mobile-menu", onClick: () => setSidebarOpen(true), "aria-label": "Open navigation", children: _jsx(Menu, { size: 20 }) }), activeRepository ? (_jsxs(_Fragment, { children: [_jsx("span", { className: "location-repository", children: activeRepository.name }), activePath && (_jsxs(_Fragment, { children: [_jsx("span", { className: "location-divider", children: "/" }), _jsx("span", { className: "location-document", children: activePath })] }))] })) : (_jsx("span", { className: "location-repository", children: "Project Workspace" }))] }), _jsx("div", { className: "header-actions", children: activeRepository && (_jsxs(_Fragment, { children: [_jsxs("button", { className: "header-button", onClick: () => void refresh(), title: "Sync repository", disabled: syncing, children: [_jsx(RefreshCw, { className: syncing ? "spin" : undefined, size: 16 }), " ", _jsx("span", { children: syncing ? "Syncing…" : "Sync" })] }), canManageRepositories && _jsxs("div", { className: "menu-wrap", children: [_jsx("button", { className: "icon-button", onClick: () => setRepoMenuOpen(!repoMenuOpen), "aria-label": "Repository options", children: _jsx(MoreHorizontal, { size: 19 }) }), repoMenuOpen && (_jsxs("div", { className: "context-menu", children: [_jsx("div", { className: "context-menu-title", children: "Repository" }), _jsxs("button", { onClick: openCredentialUpdate, children: [_jsx(KeyRound, { size: 15 }), " Update access token"] }), _jsxs("button", { className: "danger", onClick: () => void removeRepository(), children: [_jsx(Trash2, { size: 15 }), " Remove from workspace"] }), _jsx("small", { children: "The GitHub repository stays untouched." })] }))] })] })) })] }), _jsxs("div", { className: "workspace-content", children: [error && (_jsxs("div", { className: "error-banner", role: "alert", children: [_jsx("span", { children: error }), _jsx("button", { onClick: () => setError(""), children: _jsx(X, { size: 15 }) })] })), !loadingRepositories && repositories.length === 0 ? (_jsx(EmptyWorkspace, { onAdd: canManageRepositories ? openAddRepository : undefined })) : !activeRepository ? (_jsx("div", { className: "center-state", children: _jsx("div", { className: "loading-pulse" }) })) : files.length === 0 && !loadingDocument ? (_jsx(NoDocuments, { repository: activeRepository })) : document ? (_jsxs("div", { className: `document-view ${loadingDocument ? "loading" : ""}`, children: [_jsxs("div", { className: "document-hero", children: [_jsx("div", { className: `document-icon ${activeDocumentIsMermaid ? "mermaid" : ""}`, children: activeDocumentIsMermaid ? _jsx(Workflow, { size: 21 }) : _jsx(FileText, { size: 21 }) }), _jsxs("div", { className: "document-heading", children: [_jsx("div", { className: "eyebrow", children: activeDocumentIsMermaid
                                                            ? "Mermaid diagram"
                                                            : document.path.toLowerCase() === "readme.md"
                                                                ? "Project overview"
                                                                : "Project document" }), _jsx("h1", { children: document.title }), _jsxs("div", { className: "document-meta", children: [_jsxs("span", { children: ["Updated ", formatDate(document.modifiedAt)] }), !activeDocumentIsMermaid && document.tasks.total > 0 && (_jsxs("span", { className: "task-summary", children: [_jsx(CheckCircle2, { size: 14 }), document.tasks.complete, " of ", document.tasks.total, " tasks complete"] }))] })] })] }), !activeDocumentIsMermaid && document.tasks.total > 0 && (_jsxs("div", { className: "progress-card", children: [_jsxs("div", { className: "progress-copy", children: [_jsx("span", { children: "Document progress" }), _jsxs("strong", { children: [Math.round((document.tasks.complete / document.tasks.total) * 100), "%"] })] }), _jsx("div", { className: "progress-track", children: _jsx("span", { style: { width: `${(document.tasks.complete / document.tasks.total) * 100}%` } }) })] })), activeDocumentIsMermaid ? (_jsx(MermaidDocumentPreview, { chart: document.content, dark: theme === "dark" })) : (_jsx(MarkdownPreview, { content: document.content, repositoryId: activeRepository.id, apiBasePath: apiBasePath, documentPath: document.path, dark: theme === "dark", onOpenDocument: selectDocument }))] })) : (_jsx(DocumentSkeleton, {}))] })] }), canManageRepositories && _jsx(AddRepositoryDialog, { api: api, open: addDialogOpen, repository: credentialRepository, onClose: () => {
                    setAddDialogOpen(false);
                    setCredentialRepository(null);
                }, onAdded: (repositoryId) => {
                    setActiveRepositoryId(repositoryId);
                    void loadRepositories(repositoryId);
                } })] }));
}
function EmptyWorkspace({ onAdd }) {
    return (_jsxs("div", { className: "empty-workspace", children: [_jsxs("div", { className: "empty-visual", "aria-hidden": "true", children: [_jsxs("div", { className: "visual-sidebar", children: [_jsx("span", {}), _jsx("span", {}), _jsx("span", {})] }), _jsxs("div", { className: "visual-page", children: [_jsx("span", {}), _jsx("strong", {}), _jsx("span", {}), _jsx("span", {})] })] }), _jsx("div", { className: "empty-eyebrow", children: "Your project knowledge, organized" }), _jsxs("h1", { children: ["Turn repositories into", _jsx("br", {}), "clear project workspaces."] }), _jsx("p", { children: "Connect a GitHub repository to browse its Markdown documentation, track checklist progress, and automatically receive committed updates." }), onAdd ? _jsxs("button", { className: "primary-button large", onClick: onAdd, children: [_jsx(Plus, { size: 17 }), " Add repository"] }) : _jsx("p", { className: "readonly-hint", children: "Ask a workspace admin to connect a repository." }), _jsxs("div", { className: "empty-features", children: [_jsxs("span", { children: [_jsx(BookOpen, { size: 15 }), " README home"] }), _jsxs("span", { children: [_jsx(FolderKanban, { size: 15 }), " Multiple repositories"] }), _jsxs("span", { children: [_jsx(Wifi, { size: 15 }), " Automatic GitHub sync"] })] })] }));
}
function NoDocuments({ repository }) {
    return (_jsxs("div", { className: "empty-workspace compact", children: [_jsx("div", { className: "empty-document-icon", children: _jsx(FileText, { size: 25 }) }), _jsx("h1", { children: "No Markdown yet" }), _jsxs("p", { children: ["Add a ", _jsx("code", { children: "README.md" }), ", Markdown document, or Mermaid ", _jsx("code", { children: ".mmd" }), " diagram to ", _jsx("strong", { children: repository.name }), " and push it to GitHub. It will appear here automatically."] }), _jsx("div", { className: "path-chip", children: repository.sourceUrl })] }));
}
function DocumentSkeleton() {
    return (_jsxs("div", { className: "document-skeleton", "aria-label": "Loading document", children: [_jsx("span", { className: "skeleton-label" }), _jsx("span", { className: "skeleton-title" }), _jsx("span", { className: "skeleton-meta" }), _jsx("span", { className: "skeleton-line wide" }), _jsx("span", { className: "skeleton-line" }), _jsx("span", { className: "skeleton-line short" })] }));
}
export default App;
