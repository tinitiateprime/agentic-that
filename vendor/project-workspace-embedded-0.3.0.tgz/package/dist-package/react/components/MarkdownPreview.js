import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Children, isValidElement, useMemo } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import rehypeHighlight from "rehype-highlight";
import rehypeSlug from "rehype-slug";
import rehypeAutolinkHeadings from "rehype-autolink-headings";
import rehypeSanitize, { defaultSchema } from "rehype-sanitize";
import { Check, Copy } from "lucide-react";
import { MermaidDiagram } from "./MermaidDiagram.js";
const schema = {
    ...defaultSchema,
    attributes: {
        ...defaultSchema.attributes,
        code: [...(defaultSchema.attributes?.code || []), ["className", /^language-/]],
        span: [...(defaultSchema.attributes?.span || []), ["className", /^hljs-/]],
    },
};
function resolveRelativePath(documentPath, target) {
    const cleanTarget = target.split("#")[0].split("?")[0];
    const currentDirectory = documentPath.includes("/")
        ? documentPath.slice(0, documentPath.lastIndexOf("/") + 1)
        : "";
    const url = new URL(cleanTarget, `https://workspace.local/${currentDirectory}`);
    return decodeURIComponent(url.pathname.replace(/^\//, ""));
}
function textFromChildren(value) {
    if (typeof value === "string" || typeof value === "number")
        return String(value);
    if (Array.isArray(value))
        return value.map(textFromChildren).join("");
    if (value && typeof value === "object" && "props" in value) {
        return textFromChildren(value.props.children);
    }
    return "";
}
function PreBlock({ children, dark, ...props }) {
    const child = Children.toArray(children)[0];
    if (!isValidElement(child)) {
        return _jsx("pre", { ...props, children: children });
    }
    const language = /language-([\w-]+)/.exec(child.props.className || "")?.[1];
    const code = textFromChildren(child.props.children).replace(/\n$/, "");
    if (language === "mermaid")
        return _jsx(MermaidDiagram, { chart: code, dark: dark });
    return (_jsxs("div", { className: "code-block", children: [_jsxs("div", { className: "code-toolbar", children: [_jsx("span", { children: language || "Code" }), _jsx(CopyButton, { value: code })] }), _jsx("pre", { ...props, children: children })] }));
}
export function CopyButton({ value }) {
    const copy = async (event) => {
        const button = event.currentTarget;
        await navigator.clipboard.writeText(value);
        button.dataset.copied = "true";
        window.setTimeout(() => delete button.dataset.copied, 1_400);
    };
    return (_jsxs("button", { className: "copy-button", onClick: copy, "aria-label": "Copy code", children: [_jsx(Copy, { className: "copy-icon", size: 14 }), _jsx(Check, { className: "copied-icon", size: 14 }), _jsx("span", { className: "copy-label", children: "Copy" }), _jsx("span", { className: "copied-label", children: "Copied" })] }));
}
export function MarkdownPreview({ content, repositoryId, apiBasePath, documentPath, dark, onOpenDocument, }) {
    const components = useMemo(() => ({
        pre: (props) => _jsx(PreBlock, { ...props, dark: dark }),
        a: ({ href = "", children, ...props }) => {
            const external = /^(https?:|mailto:|tel:)/i.test(href);
            const isWorkspaceDocument = /\.(?:md|mdown|mmd|mermaid)(?:[#?].*)?$/i.test(href);
            if (!external && isWorkspaceDocument) {
                const targetPath = resolveRelativePath(documentPath, href);
                return (_jsx("a", { href: href, ...props, onClick: (event) => {
                        event.preventDefault();
                        onOpenDocument(targetPath);
                    }, children: children }));
            }
            return (_jsx("a", { href: href, ...props, target: external ? "_blank" : undefined, rel: external ? "noreferrer" : undefined, children: children }));
        },
        img: ({ src = "", alt = "", ...props }) => {
            const sourceValue = typeof src === "string" ? src : "";
            const external = /^(https?:|data:)/i.test(sourceValue);
            const source = external
                ? sourceValue
                : `${apiBasePath.replace(/\/+$/, "")}/repositories/${repositoryId}/asset?path=${encodeURIComponent(resolveRelativePath(documentPath, sourceValue))}`;
            return _jsx("img", { src: source, alt: alt, ...props, loading: "lazy" });
        },
    }), [apiBasePath, dark, documentPath, onOpenDocument, repositoryId]);
    return (_jsx("article", { className: "markdown-body", children: _jsx(ReactMarkdown, { remarkPlugins: [remarkGfm], rehypePlugins: [
                rehypeSlug,
                [rehypeAutolinkHeadings, { behavior: "wrap" }],
                [rehypeHighlight, { detect: false, plainText: ["mermaid"] }],
                [rehypeSanitize, schema],
            ], components: components, children: content }) }));
}
