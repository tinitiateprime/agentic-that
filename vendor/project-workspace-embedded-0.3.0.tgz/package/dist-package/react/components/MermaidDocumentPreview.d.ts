export declare function MermaidDocumentPreview({ chart, dark }: {
    chart: string;
    dark: boolean;
}): import("react").JSX.Element;
