import type { WorkspaceApi } from "../api.js";
import type { Repository } from "../types.js";
interface AddRepositoryDialogProps {
    api: WorkspaceApi;
    open: boolean;
    repository?: Repository | null;
    onClose: () => void;
    onAdded: (repositoryId: string) => void;
}
export declare function AddRepositoryDialog({ api, open, repository, onClose, onAdded, }: AddRepositoryDialogProps): import("react").JSX.Element | null;
export {};
