export declare function MermaidDiagram({ chart, dark }: {
    chart: string;
    dark: boolean;
}): import("react").JSX.Element;
