import type { FileNode } from "../types.js";
interface FileTreeProps {
    nodes: FileNode[];
    activePath: string | null;
    query: string;
    onSelect: (path: string) => void;
}
export declare function FileTree({ nodes, activePath, query, onSelect }: FileTreeProps): import("react").JSX.Element;
export {};
