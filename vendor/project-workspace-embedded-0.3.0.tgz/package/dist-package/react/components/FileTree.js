import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useMemo, useState } from "react";
import { ChevronRight, FileText, Folder, FolderOpen, Workflow } from "lucide-react";
function filterNodes(nodes, query) {
    if (!query)
        return nodes;
    const normalizedQuery = query.toLowerCase();
    return nodes.flatMap((node) => {
        if (node.type === "file") {
            return node.name.toLowerCase().includes(normalizedQuery) ||
                node.path.toLowerCase().includes(normalizedQuery)
                ? [node]
                : [];
        }
        const children = filterNodes(node.children || [], query);
        return children.length ? [{ ...node, children }] : [];
    });
}
function TreeBranch({ node, depth, activePath, forceOpen, onSelect, }) {
    const [open, setOpen] = useState(depth < 1);
    if (node.type === "directory") {
        const expanded = forceOpen || open;
        return (_jsxs("li", { children: [_jsxs("button", { className: "tree-row directory-row", style: { paddingLeft: 12 + depth * 14 }, onClick: () => setOpen((value) => !value), "aria-expanded": expanded, children: [_jsx(ChevronRight, { className: `tree-chevron ${expanded ? "expanded" : ""}`, size: 14 }), expanded ? _jsx(FolderOpen, { size: 16 }) : _jsx(Folder, { size: 16 }), _jsx("span", { children: node.name })] }), expanded && (_jsx("ul", { children: (node.children || []).map((child) => (_jsx(TreeBranch, { node: child, depth: depth + 1, activePath: activePath, forceOpen: forceOpen, onSelect: onSelect }, child.path))) }))] }));
    }
    return (_jsx("li", { children: _jsxs("button", { className: `tree-row file-row ${activePath === node.path ? "active" : ""}`, style: { paddingLeft: 31 + depth * 14 }, onClick: () => onSelect(node.path), title: node.path, children: [node.kind === "mermaid" ? _jsx(Workflow, { className: "mermaid-file-icon", size: 15 }) : _jsx(FileText, { size: 15 }), _jsx("span", { children: node.isReadme
                        ? "Overview"
                        : node.name.replace(/\.(?:md|mdown|mmd|mermaid)$/i, "") }), node.isReadme && _jsx("span", { className: "home-label", children: "Home" }), node.kind === "mermaid" && _jsx("span", { className: "kind-label", children: "Diagram" })] }) }));
}
export function FileTree({ nodes, activePath, query, onSelect }) {
    const filteredNodes = useMemo(() => filterNodes(nodes, query.trim()), [nodes, query]);
    if (!filteredNodes.length) {
        return _jsx("div", { className: "tree-empty", children: query ? "No matching documents" : "No Markdown or Mermaid documents" });
    }
    return (_jsx("nav", { className: "file-tree", "aria-label": "Repository documents", children: _jsx("ul", { children: filteredNodes.map((node) => (_jsx(TreeBranch, { node: node, depth: 0, activePath: activePath, forceOpen: Boolean(query.trim()), onSelect: onSelect }, node.path))) }) }));
}
