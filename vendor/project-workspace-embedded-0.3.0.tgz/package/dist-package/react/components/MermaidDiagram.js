import { jsx as _jsx } from "react/jsx-runtime";
import { useEffect, useId, useState } from "react";
export function MermaidDiagram({ chart, dark }) {
    const generatedId = useId().replace(/:/g, "");
    const [svg, setSvg] = useState("");
    const [error, setError] = useState("");
    useEffect(() => {
        let cancelled = false;
        setSvg("");
        setError("");
        void import("mermaid")
            .then(({ default: mermaid }) => {
            mermaid.initialize({
                startOnLoad: false,
                securityLevel: "strict",
                theme: dark ? "dark" : "neutral",
                fontFamily: "DM Sans, ui-sans-serif, system-ui, sans-serif",
            });
            return mermaid.render(`mermaid-${generatedId}`, chart);
        })
            .then((result) => {
            if (!cancelled) {
                setSvg(result.svg);
                setError("");
            }
        })
            .catch(() => {
            if (!cancelled)
                setError("This Mermaid diagram could not be rendered.");
        });
        return () => {
            cancelled = true;
        };
    }, [chart, dark, generatedId]);
    if (error)
        return _jsx("div", { className: "mermaid-error", children: error });
    if (!svg)
        return _jsx("div", { className: "diagram-loading", children: "Rendering diagram\u2026" });
    return _jsx("div", { className: "mermaid-diagram", dangerouslySetInnerHTML: { __html: svg } });
}
