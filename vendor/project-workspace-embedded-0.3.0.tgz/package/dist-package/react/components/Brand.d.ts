export declare function Brand({ compact }: {
    compact?: boolean;
}): import("react").JSX.Element;
