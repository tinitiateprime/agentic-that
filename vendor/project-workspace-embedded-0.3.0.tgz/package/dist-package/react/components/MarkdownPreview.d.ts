interface MarkdownPreviewProps {
    content: string;
    repositoryId: string;
    apiBasePath: string;
    documentPath: string;
    dark: boolean;
    onOpenDocument: (path: string) => void;
}
export declare function CopyButton({ value }: {
    value: string;
}): import("react").JSX.Element;
export declare function MarkdownPreview({ content, repositoryId, apiBasePath, documentPath, dark, onOpenDocument, }: MarkdownPreviewProps): import("react").JSX.Element;
export {};
