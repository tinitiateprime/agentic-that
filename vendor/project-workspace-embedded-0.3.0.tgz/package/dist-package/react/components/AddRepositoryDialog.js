import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useRef, useState } from "react";
import { FolderGit2, KeyRound, LoaderCircle, X } from "lucide-react";
export function AddRepositoryDialog({ api, open, repository, onClose, onAdded, }) {
    const [repositoryUrl, setRepositoryUrl] = useState("");
    const [name, setName] = useState("");
    const [token, setToken] = useState("");
    const [error, setError] = useState("");
    const [submitting, setSubmitting] = useState(false);
    const urlInput = useRef(null);
    const tokenInput = useRef(null);
    const editing = Boolean(repository);
    useEffect(() => {
        if (!open)
            return;
        setRepositoryUrl(repository?.sourceUrl || "");
        setName("");
        setToken("");
        setError("");
        window.setTimeout(() => {
            if (repository)
                tokenInput.current?.focus();
            else
                urlInput.current?.focus();
        }, 50);
    }, [open, repository]);
    useEffect(() => {
        if (!open)
            return;
        const closeOnEscape = (event) => {
            if (event.key === "Escape" && !submitting)
                onClose();
        };
        window.addEventListener("keydown", closeOnEscape);
        return () => window.removeEventListener("keydown", closeOnEscape);
    }, [onClose, open, submitting]);
    if (!open)
        return null;
    async function submit(event) {
        event.preventDefault();
        setSubmitting(true);
        setError("");
        try {
            const result = repository
                ? await api.updateRepositoryCredential(repository.id, token)
                : await api.addRepository(repositoryUrl, token, name);
            setToken("");
            onAdded(result.repository.id);
            onClose();
        }
        catch (submitError) {
            setError(submitError instanceof Error
                ? submitError.message
                : editing
                    ? "Could not update repository access."
                    : "Could not add repository.");
        }
        finally {
            setSubmitting(false);
        }
    }
    return (_jsx("div", { className: "dialog-backdrop", role: "presentation", onMouseDown: () => {
            if (!submitting)
                onClose();
        }, children: _jsxs("section", { className: "dialog", role: "dialog", "aria-modal": "true", "aria-labelledby": "add-repository-title", onMouseDown: (event) => event.stopPropagation(), children: [_jsx("button", { className: "icon-button dialog-close", onClick: onClose, "aria-label": "Close", disabled: submitting, children: _jsx(X, { size: 18 }) }), _jsx("div", { className: "dialog-icon", children: editing ? _jsx(KeyRound, { size: 22 }) : _jsx(FolderGit2, { size: 22 }) }), _jsx("h2", { id: "add-repository-title", children: editing ? "Update GitHub access" : "Add a GitHub repository or folder" }), _jsx("p", { children: editing
                        ? `Replace the read-only access token used for ${repository?.name}.`
                        : "Connect a complete repository or scope the workspace to one folder." }), _jsxs("form", { onSubmit: submit, children: [_jsx("label", { htmlFor: "repository-url", children: "GitHub repository URL" }), _jsx("input", { id: "repository-url", ref: urlInput, type: "url", inputMode: "url", value: repositoryUrl, onChange: (event) => setRepositoryUrl(event.target.value), placeholder: "https://github.com/company/project", required: true, readOnly: editing, spellCheck: false, autoComplete: "url" }), _jsxs("span", { className: "field-help", children: ["Repository and ", _jsx("code", { children: "/tree/branch/folder" }), " URLs are supported. Nothing is cloned."] }), !editing && (_jsxs(_Fragment, { children: [_jsxs("label", { htmlFor: "repository-name", children: ["Display name ", _jsx("span", { children: "Optional" })] }), _jsx("input", { id: "repository-name", value: name, onChange: (event) => setName(event.target.value), placeholder: "Uses the repository name by default", maxLength: 80 })] })), _jsx("label", { htmlFor: "repository-token", children: "Fine-grained access token" }), _jsx("input", { id: "repository-token", ref: tokenInput, type: "password", value: token, onChange: (event) => setToken(event.target.value), placeholder: "github_pat_...", minLength: 20, maxLength: 500, required: true, spellCheck: false, autoComplete: "new-password", "aria-describedby": "repository-token-help" }), _jsxs("span", { id: "repository-token-help", className: "field-help", children: ["Select read-only repository contents access. The token is encrypted and never shown again.", " ", _jsx("a", { href: "https://github.com/settings/personal-access-tokens/new", target: "_blank", rel: "noreferrer", children: "Create token" })] }), error && _jsx("div", { className: "form-error", role: "alert", children: error }), _jsxs("div", { className: "dialog-actions", children: [_jsx("button", { type: "button", className: "secondary-button", onClick: onClose, disabled: submitting, children: "Cancel" }), _jsxs("button", { type: "submit", className: "primary-button", disabled: submitting || !repositoryUrl.trim() || token.trim().length < 20, children: [submitting && _jsx(LoaderCircle, { className: "spin", size: 16 }), submitting ? "Verifying…" : editing ? "Update access" : "Add repository"] })] })] })] }) }));
}
