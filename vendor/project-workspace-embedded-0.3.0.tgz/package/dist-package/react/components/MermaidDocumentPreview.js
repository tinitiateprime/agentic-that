import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { Code2, Workflow } from "lucide-react";
import { CopyButton } from "./MarkdownPreview.js";
import { MermaidDiagram } from "./MermaidDiagram.js";
export function MermaidDocumentPreview({ chart, dark }) {
    const [view, setView] = useState("diagram");
    return (_jsxs("section", { className: "mermaid-document", "aria-label": "Mermaid document preview", children: [_jsxs("header", { className: "mermaid-document-toolbar", children: [_jsxs("div", { children: [_jsx("strong", { children: view === "diagram" ? "Rendered diagram" : "Mermaid source" }), _jsx("span", { children: view === "diagram" ? "Interactive documentation preview" : "Version-controlled diagram definition" })] }), _jsxs("div", { className: "diagram-view-switch", "aria-label": "Diagram view", children: [_jsxs("button", { type: "button", className: view === "diagram" ? "active" : "", onClick: () => setView("diagram"), "aria-pressed": view === "diagram", children: [_jsx(Workflow, { size: 14 }), " Diagram"] }), _jsxs("button", { type: "button", className: view === "source" ? "active" : "", onClick: () => setView("source"), "aria-pressed": view === "source", children: [_jsx(Code2, { size: 14 }), " Source"] })] })] }), view === "diagram" ? (_jsx("div", { className: "mermaid-document-canvas", children: _jsx(MermaidDiagram, { chart: chart, dark: dark }) })) : (_jsxs("div", { className: "mermaid-source", children: [_jsxs("div", { className: "code-toolbar", children: [_jsx("span", { children: "Mermaid" }), _jsx(CopyButton, { value: chart })] }), _jsx("pre", { children: _jsx("code", { children: chart }) })] }))] }));
}
