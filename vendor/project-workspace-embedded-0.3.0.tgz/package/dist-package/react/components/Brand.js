import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
export function Brand({ compact = false }) {
    return (_jsxs("div", { className: "brand", "aria-label": "Project Workspace", children: [_jsxs("div", { className: "brand-mark", "aria-hidden": "true", children: [_jsx("span", {}), _jsx("span", {}), _jsx("span", {})] }), !compact && (_jsxs("div", { className: "brand-copy", children: [_jsx("strong", { children: "Project" }), _jsx("span", { children: "Workspace" })] }))] }));
}
