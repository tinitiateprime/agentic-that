"use client";
import { jsx as _jsx } from "react/jsx-runtime";
import App from "./App.js";
/** Drop this client component into a React or Next.js page in the host SaaS. */
export function ProjectWorkspacePage(props) {
    return (_jsx(App, { apiBasePath: "/api/project-workspace", liveEvents: false, pollIntervalMs: 300_000, ...props }));
}
