export interface ProjectWorkspacePageProps {
    /** Same path used by the host's API route. */
    apiBasePath?: string;
    /** Set this to a stable tenant/user key when the host can switch accounts. */
    storageKey?: string;
    /** Match the permission returned by the server's getIdentity callback. */
    canManageRepositories?: boolean;
    /** Use SSE on long-running Node servers. */
    liveEvents?: boolean;
    /** Browser sync interval; useful when a serverless host cannot keep SSE open. */
    pollIntervalMs?: number;
    className?: string;
}
declare function App({ apiBasePath, storageKey, canManageRepositories, liveEvents, pollIntervalMs, className, }: ProjectWorkspacePageProps): import("react").JSX.Element;
export default App;
