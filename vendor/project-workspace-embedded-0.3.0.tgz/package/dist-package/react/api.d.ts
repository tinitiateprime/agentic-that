import type { DocumentPayload, FileNode, Repository } from "./types.js";
export declare function createWorkspaceApi(apiBasePath?: string): {
    repositories(): Promise<{
        repositories: Repository[];
    }>;
    addRepository(url: string, token: string, name?: string): Promise<{
        repository: Repository;
    }>;
    updateRepositoryCredential(id: string, token: string): Promise<{
        repository: Repository;
    }>;
    syncRepository(id: string): Promise<{
        repository: Repository;
        changed: boolean;
    }>;
    removeRepository(id: string): Promise<void>;
    files(id: string): Promise<{
        nodes: FileNode[];
        fileCount: number;
    }>;
    document(id: string, path: string): Promise<DocumentPayload>;
    asset(id: string, path: string): string;
    events(): string;
};
export declare const api: {
    repositories(): Promise<{
        repositories: Repository[];
    }>;
    addRepository(url: string, token: string, name?: string): Promise<{
        repository: Repository;
    }>;
    updateRepositoryCredential(id: string, token: string): Promise<{
        repository: Repository;
    }>;
    syncRepository(id: string): Promise<{
        repository: Repository;
        changed: boolean;
    }>;
    removeRepository(id: string): Promise<void>;
    files(id: string): Promise<{
        nodes: FileNode[];
        fileCount: number;
    }>;
    document(id: string, path: string): Promise<DocumentPayload>;
    asset(id: string, path: string): string;
    events(): string;
};
export type WorkspaceApi = ReturnType<typeof createWorkspaceApi>;
