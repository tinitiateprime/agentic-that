async function request(url, options) {
    const response = await fetch(url, {
        ...options,
        headers: { "Content-Type": "application/json", ...options?.headers },
    });
    if (!response.ok) {
        const body = (await response.json().catch(() => ({})));
        throw new Error(body.message || `Request failed (${response.status}).`);
    }
    if (response.status === 204)
        return undefined;
    return response.json();
}
export function createWorkspaceApi(apiBasePath = "/api") {
    const basePath = apiBasePath.replace(/\/+$/, "");
    if (!basePath.startsWith("/") || !basePath || basePath.startsWith("//")) {
        throw new Error("apiBasePath must be an absolute path on the SaaS site.");
    }
    return {
        async repositories() {
            return request(`${basePath}/repositories`);
        },
        async addRepository(url, token, name) {
            return request(`${basePath}/repositories`, {
                method: "POST",
                body: JSON.stringify({ url, token, name: name || undefined }),
            });
        },
        async updateRepositoryCredential(id, token) {
            return request(`${basePath}/repositories/${id}/credentials`, {
                method: "PUT",
                body: JSON.stringify({ token }),
            });
        },
        async syncRepository(id) {
            return request(`${basePath}/repositories/${id}/sync`, { method: "POST" });
        },
        async removeRepository(id) {
            return request(`${basePath}/repositories/${id}`, { method: "DELETE" });
        },
        async files(id) {
            return request(`${basePath}/repositories/${id}/files`);
        },
        async document(id, path) {
            return request(`${basePath}/repositories/${id}/document?path=${encodeURIComponent(path)}`);
        },
        asset(id, path) {
            return `${basePath}/repositories/${id}/asset?path=${encodeURIComponent(path)}`;
        },
        events() {
            return `${basePath}/events`;
        },
    };
}
export const api = createWorkspaceApi();
