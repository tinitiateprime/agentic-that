import { type ProjectWorkspacePageProps } from "./App.js";
export type EmbeddedProjectWorkspacePageProps = Omit<ProjectWorkspacePageProps, "storageKey" | "canManageRepositories"> & {
    /** Unique to the signed-in tenant and user, so browser preferences stay separate. */
    storageKey: string;
    /** Keep this in sync with the server identity's permission. */
    canManageRepositories: boolean;
};
/** Drop this client component into a React or Next.js page in the host SaaS. */
export declare function ProjectWorkspacePage(props: EmbeddedProjectWorkspacePageProps): import("react").JSX.Element;
export type { DocumentPayload, FileNode, Repository } from "./types.js";
