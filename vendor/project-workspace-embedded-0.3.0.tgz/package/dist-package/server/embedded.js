import { createHash, createHmac, timingSafeEqual } from "node:crypto";
import path from "node:path";
import mime from "mime-types";
import { z } from "zod";
import { RepositoryStore } from "./repository-store.js";
const MAX_JSON_BYTES = 1024 * 1024;
const encoder = new TextEncoder();
function normalizeBasePath(value) {
    const normalized = `/${value.trim().replace(/^\/+|\/+$/g, "")}`;
    if (normalized === "/" || normalized.includes("//") || normalized.includes("?") || normalized.includes("#")) {
        throw new Error("apiBasePath must be a non-root URL path.");
    }
    return normalized;
}
function json(value, status = 200) {
    return new Response(JSON.stringify(value), {
        status,
        headers: {
            "Content-Type": "application/json; charset=utf-8",
            "Cache-Control": "private, no-store",
            "X-Content-Type-Options": "nosniff",
        },
    });
}
function errorStatus(error) {
    if (error instanceof z.ZodError || error instanceof SyntaxError)
        return 400;
    if (typeof error === "object" && error && "statusCode" in error) {
        const status = Number(error.statusCode);
        if (Number.isInteger(status) && status >= 400 && status <= 599)
            return status;
    }
    return 500;
}
function errorResponse(error) {
    const status = errorStatus(error);
    if (status >= 500)
        console.error(error);
    const message = error instanceof z.ZodError
        ? error.issues[0]?.message || "Invalid request."
        : status === 500
            ? "Project Workspace could not complete the request."
            : error instanceof Error
                ? error.message
                : "Invalid request.";
    return json({ message }, status);
}
async function readBytes(request) {
    if (Number(request.headers.get("content-length") || 0) > MAX_JSON_BYTES) {
        return Promise.reject(Object.assign(new Error("Request body is too large."), { statusCode: 413 }));
    }
    const reader = request.body?.getReader();
    if (!reader)
        throw new SyntaxError("A request body is required.");
    const chunks = [];
    let size = 0;
    while (true) {
        const { value, done } = await reader.read();
        if (done)
            break;
        size += value.byteLength;
        if (size > MAX_JSON_BYTES) {
            await reader.cancel();
            throw Object.assign(new Error("Request body is too large."), { statusCode: 413 });
        }
        chunks.push(value);
    }
    return Buffer.concat(chunks);
}
async function readJson(request) {
    if (!/^application\/json(?:;|$)/i.test(request.headers.get("content-type") || "")) {
        throw Object.assign(new Error("Send JSON with Content-Type: application/json."), { statusCode: 415 });
    }
    return JSON.parse((await readBytes(request)).toString("utf8"));
}
function requestOriginIsAllowed(request) {
    const fetchSite = request.headers.get("sec-fetch-site");
    if (fetchSite && !["same-origin", "none"].includes(fetchSite))
        return false;
    const origin = request.headers.get("origin");
    if (!origin)
        return true;
    try {
        return new URL(origin).origin === new URL(request.url).origin;
    }
    catch {
        return false;
    }
}
/**
 * Framework-neutral Node.js API handler. Mount it at apiBasePath in a Next.js
 * route handler, or use the Express adapter from the /express export.
 */
export function createProjectWorkspaceHandler(options) {
    if (!options || typeof options.getIdentity !== "function") {
        throw new Error("Project Workspace requires getIdentity to use the host SaaS login.");
    }
    if (!options.dataDirectory || !path.isAbsolute(options.dataDirectory)) {
        throw new Error("Project Workspace requires an absolute, persistent dataDirectory.");
    }
    const basePath = normalizeBasePath(options.apiBasePath || "/api/project-workspace");
    const dataRoot = path.resolve(options.dataDirectory);
    const stores = new Map();
    const eventClients = new Map();
    function storeForTenant(tenantId) {
        const key = createHash("sha256").update(tenantId).digest("hex");
        let current = stores.get(key);
        if (!current) {
            const store = new RepositoryStore(path.join(dataRoot, "tenants", key));
            current = store.initialize().then(() => store).catch((error) => {
                stores.delete(key);
                throw error;
            });
            stores.set(key, current);
        }
        return current;
    }
    function broadcast(tenantId, payload) {
        const clients = eventClients.get(tenantId);
        if (!clients)
            return;
        const bytes = encoder.encode(`data: ${JSON.stringify(payload)}\n\n`);
        for (const client of clients) {
            try {
                client.enqueue(bytes);
            }
            catch {
                clients.delete(client);
            }
        }
        if (clients.size === 0)
            eventClients.delete(tenantId);
    }
    function events(request, tenantId) {
        let close;
        const stream = new ReadableStream({
            start(controller) {
                let clients = eventClients.get(tenantId);
                if (!clients) {
                    clients = new Set();
                    eventClients.set(tenantId, clients);
                }
                clients.add(controller);
                controller.enqueue(encoder.encode(": connected\n\n"));
                const heartbeat = setInterval(() => {
                    try {
                        controller.enqueue(encoder.encode(": keepalive\n\n"));
                    }
                    catch {
                        close?.();
                    }
                }, 25_000);
                close = () => {
                    clearInterval(heartbeat);
                    request.signal.removeEventListener("abort", close);
                    clients.delete(controller);
                    if (clients.size === 0)
                        eventClients.delete(tenantId);
                    try {
                        controller.close();
                    }
                    catch { /* already closed */ }
                };
                request.signal.addEventListener("abort", close, { once: true });
            },
            cancel() { close?.(); },
        });
        return new Response(stream, {
            headers: {
                "Content-Type": "text/event-stream; charset=utf-8",
                "Cache-Control": "private, no-cache, no-transform",
                "X-Accel-Buffering": "no",
                "X-Content-Type-Options": "nosniff",
            },
        });
    }
    async function webhook(request) {
        const configured = options.webhook;
        if (!configured?.secret || typeof configured.tenantIdsForRepository !== "function") {
            return json({ message: "GitHub webhooks are not configured." }, 503);
        }
        const body = await readBytes(request);
        const received = request.headers.get("x-hub-signature-256") || "";
        const expected = `sha256=${createHmac("sha256", configured.secret).update(body).digest("hex")}`;
        const receivedBytes = Buffer.from(received);
        const expectedBytes = Buffer.from(expected);
        if (receivedBytes.length !== expectedBytes.length || !timingSafeEqual(receivedBytes, expectedBytes)) {
            return json({ message: "Invalid GitHub webhook signature." }, 401);
        }
        const event = request.headers.get("x-github-event");
        if (event === "ping")
            return json({ accepted: true });
        if (event !== "push")
            return json({ accepted: true, ignored: true }, 202);
        const payload = z.object({
            ref: z.string(),
            repository: z.object({ full_name: z.string() }),
        }).parse(JSON.parse(body.toString("utf8")));
        const tenantIds = [...new Set(await configured.tenantIdsForRepository(payload.repository.full_name))]
            .filter((value) => typeof value === "string" && value.trim());
        const jobs = await Promise.all(tenantIds.map(async (tenantId) => {
            const store = await storeForTenant(tenantId);
            const matches = store.findAllByFullName(payload.repository.full_name)
                .filter((repository) => payload.ref === `refs/heads/${repository.ref}`);
            return Promise.allSettled(matches.map(async (repository) => {
                await store.sync(repository.id);
                broadcast(tenantId, {
                    type: "repository-changed",
                    repositoryId: repository.id,
                    event: "github-webhook",
                    path: "",
                });
            }));
        }));
        return json({ accepted: true, tenantsChecked: jobs.length }, 202);
    }
    return async function handleProjectWorkspaceRequest(request) {
        try {
            const url = new URL(request.url);
            if (url.pathname !== basePath && !url.pathname.startsWith(`${basePath}/`)) {
                return json({ message: "Project Workspace route not found." }, 404);
            }
            const route = url.pathname.slice(basePath.length) || "/";
            if (request.method === "POST" && route === "/github/webhook")
                return webhook(request);
            const identity = await options.getIdentity(request);
            if (!identity || !identity.userId?.trim() || !identity.tenantId?.trim()) {
                return json({ message: "Sign in to use Project Workspace." }, 401);
            }
            if (typeof identity.canManageRepositories !== "boolean") {
                throw new Error("getIdentity must return canManageRepositories.");
            }
            if (!["GET", "HEAD", "OPTIONS"].includes(request.method) && !requestOriginIsAllowed(request)) {
                return json({ message: "Cross-origin requests are not allowed." }, 403);
            }
            if (request.method === "GET" && route === "/events")
                return events(request, identity.tenantId);
            const store = await storeForTenant(identity.tenantId);
            const requireManager = () => {
                if (!identity.canManageRepositories) {
                    throw Object.assign(new Error("You cannot manage repositories in this workspace."), { statusCode: 403 });
                }
            };
            const findRepository = (id) => {
                const repository = store.get(id);
                if (!repository)
                    throw Object.assign(new Error("Repository not found."), { statusCode: 404 });
                return repository;
            };
            if (request.method === "GET" && route === "/repositories") {
                return json({ repositories: store.summaries() });
            }
            if (request.method === "POST" && route === "/repositories") {
                requireManager();
                const input = z.object({
                    url: z.string().trim().min(1),
                    name: z.string().trim().max(80).optional(),
                    token: z.string().trim().min(20).max(500),
                }).parse(await readJson(request));
                const repository = await store.add(input.url, input.name, input.token);
                return json({ repository: store.summaries().find((item) => item.id === repository.id) }, 201);
            }
            const match = /^\/repositories\/([^/]+)(?:\/(credentials|sync|files|document|asset))?$/.exec(route);
            if (!match)
                return json({ message: "Project Workspace route not found." }, 404);
            const id = decodeURIComponent(match[1]);
            const action = match[2];
            if (request.method === "PUT" && action === "credentials") {
                requireManager();
                findRepository(id);
                const input = z.object({ token: z.string().trim().min(20).max(500) }).parse(await readJson(request));
                await store.updateCredential(id, input.token);
                return json({ repository: store.summaries().find((item) => item.id === id) });
            }
            if (request.method === "POST" && action === "sync") {
                findRepository(id);
                const result = await store.sync(id);
                if (result.changed) {
                    broadcast(identity.tenantId, { type: "repository-changed", repositoryId: id, event: "github-sync", path: "" });
                }
                return json({
                    repository: store.summaries().find((item) => item.id === id),
                    changed: result.changed,
                });
            }
            if (request.method === "DELETE" && !action) {
                requireManager();
                if (!await store.remove(id))
                    return json({ message: "Repository not found." }, 404);
                return new Response(null, { status: 204, headers: { "Cache-Control": "private, no-store" } });
            }
            if (request.method === "GET" && action === "files") {
                findRepository(id);
                return json(await store.files(id));
            }
            if (request.method === "GET" && action === "document") {
                findRepository(id);
                const query = z.object({ path: z.string().trim().min(1) }).parse(Object.fromEntries(url.searchParams));
                return json(await store.document(id, query.path));
            }
            if (request.method === "GET" && action === "asset") {
                findRepository(id);
                const query = z.object({ path: z.string().trim().min(1) }).parse(Object.fromEntries(url.searchParams));
                const assetMime = mime.lookup(query.path);
                if (typeof assetMime !== "string" || !(assetMime.startsWith("image/") || assetMime === "application/pdf")) {
                    return json({ message: "This asset type cannot be previewed." }, 415);
                }
                const asset = await store.asset(id, query.path);
                const etag = `"${asset.sha}"`;
                if (request.headers.get("if-none-match") === etag) {
                    return new Response(null, { status: 304, headers: { ETag: etag, "Cache-Control": "private, max-age=300" } });
                }
                return new Response(new Uint8Array(asset.content), {
                    headers: {
                        "Content-Type": assetMime,
                        "Content-Length": String(asset.content.length),
                        ETag: etag,
                        "Cache-Control": "private, max-age=300",
                        "Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'; sandbox",
                        "X-Content-Type-Options": "nosniff",
                    },
                });
            }
            return json({ message: "Method not allowed." }, 405);
        }
        catch (error) {
            return errorResponse(error);
        }
    };
}
