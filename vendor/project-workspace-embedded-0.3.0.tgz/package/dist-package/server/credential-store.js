import { createCipheriv, createDecipheriv, randomBytes } from "node:crypto";
import path from "node:path";
import { mkdir, readFile, writeFile } from "node:fs/promises";
export class CredentialStore {
    dataDirectory;
    credentialsFile;
    keyFile;
    key;
    credentials = {};
    constructor(dataDirectory) {
        this.dataDirectory = dataDirectory;
        this.credentialsFile = path.join(dataDirectory, "credentials.json");
        this.keyFile = path.join(dataDirectory, "token-encryption.key");
    }
    async initialize() {
        await mkdir(this.dataDirectory, { recursive: true });
        this.key = await this.loadKey();
        try {
            const value = JSON.parse(await readFile(this.credentialsFile, "utf8"));
            this.credentials = isCredentialMap(value) ? value : {};
        }
        catch (error) {
            if (error.code !== "ENOENT")
                throw error;
            await this.persist();
        }
    }
    has(repositoryId) {
        return Boolean(this.credentials[repositoryId]);
    }
    get(repositoryId) {
        const credential = this.credentials[repositoryId];
        if (!credential)
            return undefined;
        const key = this.requireKey();
        try {
            const decipher = createDecipheriv("aes-256-gcm", key, Buffer.from(credential.iv, "base64"));
            decipher.setAuthTag(Buffer.from(credential.tag, "base64"));
            return Buffer.concat([
                decipher.update(Buffer.from(credential.ciphertext, "base64")),
                decipher.final(),
            ]).toString("utf8");
        }
        catch {
            throw new Error("The saved GitHub credential could not be decrypted.");
        }
    }
    async set(repositoryId, token) {
        const key = this.requireKey();
        const iv = randomBytes(12);
        const cipher = createCipheriv("aes-256-gcm", key, iv);
        const ciphertext = Buffer.concat([cipher.update(token, "utf8"), cipher.final()]);
        this.credentials[repositoryId] = {
            version: 1,
            iv: iv.toString("base64"),
            tag: cipher.getAuthTag().toString("base64"),
            ciphertext: ciphertext.toString("base64"),
        };
        await this.persist();
    }
    async remove(repositoryId) {
        if (!this.credentials[repositoryId])
            return;
        delete this.credentials[repositoryId];
        await this.persist();
    }
    async loadKey() {
        const configured = process.env.PROJECT_WORKSPACE_TOKEN_ENCRYPTION_KEY?.trim() ||
            process.env.TOKEN_ENCRYPTION_KEY?.trim();
        if (configured) {
            const key = /^[0-9a-f]{64}$/i.test(configured)
                ? Buffer.from(configured, "hex")
                : Buffer.from(configured, "base64");
            if (key.length !== 32) {
                throw new Error("PROJECT_WORKSPACE_TOKEN_ENCRYPTION_KEY must be 32 bytes encoded as 64 hex characters or base64.");
            }
            return key;
        }
        try {
            const key = Buffer.from((await readFile(this.keyFile, "utf8")).trim(), "base64");
            if (key.length !== 32)
                throw new Error("Invalid generated token encryption key.");
            return key;
        }
        catch (error) {
            if (error.code !== "ENOENT")
                throw error;
        }
        const key = randomBytes(32);
        try {
            await writeFile(this.keyFile, `${key.toString("base64")}\n`, {
                encoding: "utf8",
                flag: "wx",
                mode: 0o600,
            });
            return key;
        }
        catch (error) {
            if (error.code !== "EEXIST")
                throw error;
            const existing = Buffer.from((await readFile(this.keyFile, "utf8")).trim(), "base64");
            if (existing.length !== 32)
                throw new Error("Invalid generated token encryption key.");
            return existing;
        }
    }
    requireKey() {
        if (!this.key)
            throw new Error("Credential storage is not initialized.");
        return this.key;
    }
    async persist() {
        await writeFile(this.credentialsFile, `${JSON.stringify(this.credentials, null, 2)}\n`, {
            encoding: "utf8",
            mode: 0o600,
        });
    }
}
function isCredentialMap(value) {
    if (!value || typeof value !== "object" || Array.isArray(value))
        return false;
    return Object.values(value).every((credential) => {
        if (!credential || typeof credential !== "object")
            return false;
        const item = credential;
        return (item.version === 1 &&
            typeof item.iv === "string" &&
            typeof item.tag === "string" &&
            typeof item.ciphertext === "string");
    });
}
