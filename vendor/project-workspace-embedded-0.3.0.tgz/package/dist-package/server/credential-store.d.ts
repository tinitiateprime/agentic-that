export declare class CredentialStore {
    private readonly dataDirectory;
    private readonly credentialsFile;
    private readonly keyFile;
    private key?;
    private credentials;
    constructor(dataDirectory: string);
    initialize(): Promise<void>;
    has(repositoryId: string): boolean;
    get(repositoryId: string): string | undefined;
    set(repositoryId: string, token: string): Promise<void>;
    remove(repositoryId: string): Promise<void>;
    private loadKey;
    private requireKey;
    private persist;
}
