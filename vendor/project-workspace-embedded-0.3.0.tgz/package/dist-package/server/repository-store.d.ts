import type { DocumentPayload, Repository, RepositorySummary } from "./types.js";
export declare class RepositoryStore {
    private readonly dataFile;
    private readonly snapshotDirectory;
    private readonly blobDirectory;
    private readonly github;
    private readonly credentials;
    private repositories;
    private snapshots;
    private documents;
    private syncs;
    constructor(dataDirectory?: string);
    initialize(): Promise<void>;
    list(): Repository[];
    get(id: string): Repository | undefined;
    findAllByFullName(fullName: string): Repository[];
    summaries(): RepositorySummary[];
    add(gitHubUrl: string, requestedName: string | undefined, accessToken: string): Promise<Repository>;
    updateCredential(id: string, accessToken: string): Promise<Repository>;
    sync(id: string): Promise<{
        repository: Repository;
        changed: boolean;
    }>;
    remove(id: string): Promise<boolean>;
    files(id: string): Promise<{
        nodes: import("./types.js").FileNode[];
        fileCount: number;
    }>;
    document(id: string, requestedPath: string): Promise<DocumentPayload>;
    asset(id: string, requestedPath: string): Promise<{
        path: string;
        sha: string;
        content: Buffer<ArrayBufferLike>;
    }>;
    private performSync;
    private resolveSource;
    private filesWithinScope;
    private requireScopeContent;
    private sourceUrl;
    private defaultDisplayName;
    private setSnapshot;
    private loadSnapshot;
    private readBlob;
    private snapshotPath;
    private blobPath;
    private requireRepository;
    private requireSnapshot;
    private clearDocumentCache;
    private persist;
}
