/** Return this only after the host SaaS has verified its own login session. */
export interface ProjectWorkspaceIdentity {
    userId: string;
    tenantId: string;
    /** Users without this permission can read and sync, but cannot change registrations or tokens. */
    canManageRepositories: boolean;
}
export interface ProjectWorkspaceHandlerOptions {
    /** A persistent, private directory on a single Node.js server. */
    dataDirectory: string;
    /** Resolve the host application's session. Never take tenantId from a browser parameter. */
    getIdentity: (request: Request) => ProjectWorkspaceIdentity | null | Promise<ProjectWorkspaceIdentity | null>;
    /** Must match the React page's apiBasePath and the host API route. */
    apiBasePath?: string;
    /** Optional signed GitHub push webhook for immediate updates. */
    webhook?: {
        secret: string;
        /** Resolve tenants from your SaaS records for the repository in the push event. */
        tenantIdsForRepository: (fullName: string) => string[] | Promise<string[]>;
    };
}
/**
 * Framework-neutral Node.js API handler. Mount it at apiBasePath in a Next.js
 * route handler, or use the Express adapter from the /express export.
 */
export declare function createProjectWorkspaceHandler(options: ProjectWorkspaceHandlerOptions): (request: Request) => Promise<Response>;
