import path from "node:path";
import matter from "gray-matter";
const MAX_DOCUMENT_BYTES = 2 * 1024 * 1024;
const MAX_DOCUMENT_FILES = 5_000;
export class RepositoryFileError extends Error {
    statusCode;
    constructor(message, statusCode) {
        super(message);
        this.statusCode = statusCode;
    }
}
export function isMarkdown(fileName) {
    return /\.md(?:own)?$/i.test(fileName);
}
export function isMermaid(fileName) {
    return /\.(?:mmd|mermaid)$/i.test(fileName);
}
export function isPreviewableDocument(fileName) {
    return isMarkdown(fileName) || isMermaid(fileName);
}
export function normalizeRepositoryPath(value) {
    const portable = value.replace(/\\/g, "/").trim();
    if (!portable || portable.startsWith("/") || /^[A-Za-z]:/.test(portable) || portable.includes("\0")) {
        throw new RepositoryFileError("The requested path is outside this repository.", 403);
    }
    const segments = [];
    for (const segment of portable.split("/")) {
        if (!segment || segment === ".")
            continue;
        if (segment === "..") {
            if (segments.length === 0) {
                throw new RepositoryFileError("The requested path is outside this repository.", 403);
            }
            segments.pop();
            continue;
        }
        segments.push(segment);
    }
    if (segments.length === 0) {
        throw new RepositoryFileError("The requested path is outside this repository.", 403);
    }
    return segments.join("/");
}
function compareNodes(left, right) {
    if (left.isReadme && !right.isReadme)
        return -1;
    if (!left.isReadme && right.isReadme)
        return 1;
    if (left.type !== right.type)
        return left.type === "directory" ? -1 : 1;
    return left.name.localeCompare(right.name, undefined, { sensitivity: "base" });
}
export function buildFileTree(files, modifiedAt) {
    const documentFiles = files.filter((file) => isPreviewableDocument(file.path));
    if (documentFiles.length > MAX_DOCUMENT_FILES) {
        throw new RepositoryFileError("This repository contains too many documentation files to preview.", 413);
    }
    const root = [];
    const directories = new Map();
    for (const file of documentFiles) {
        const normalizedPath = normalizeRepositoryPath(file.path);
        const segments = normalizedPath.split("/");
        let children = root;
        let directoryPath = "";
        for (const directoryName of segments.slice(0, -1)) {
            directoryPath = directoryPath ? `${directoryPath}/${directoryName}` : directoryName;
            let directory = directories.get(directoryPath);
            if (!directory) {
                directory = {
                    name: directoryName,
                    path: directoryPath,
                    type: "directory",
                    children: [],
                };
                directories.set(directoryPath, directory);
                children.push(directory);
            }
            children = directory.children || [];
        }
        const name = segments.at(-1) || normalizedPath;
        children.push({
            name,
            path: normalizedPath,
            type: "file",
            isReadme: name.toLowerCase() === "readme.md",
            kind: isMermaid(normalizedPath) ? "mermaid" : "markdown",
            modifiedAt,
            size: file.size,
        });
    }
    const sortNodes = (nodes) => {
        nodes.sort(compareNodes);
        for (const node of nodes)
            if (node.children)
                sortNodes(node.children);
    };
    sortNodes(root);
    return { nodes: root, fileCount: documentFiles.length };
}
export function parseDocument(relativePath, source, modifiedAt, size = Buffer.byteLength(source, "utf8")) {
    const normalizedPath = normalizeRepositoryPath(relativePath);
    if (!isPreviewableDocument(normalizedPath)) {
        throw new RepositoryFileError("Only Markdown and Mermaid documents can be previewed.", 400);
    }
    if (size > MAX_DOCUMENT_BYTES) {
        throw new RepositoryFileError("This document is larger than the 2 MB preview limit.", 413);
    }
    const kind = isMermaid(normalizedPath) ? "mermaid" : "markdown";
    const parsed = kind === "markdown"
        ? matter(source)
        : { content: source, data: {} };
    const heading = parsed.content.match(/^\s*#\s+(.+)$/m)?.[1]?.trim();
    const fileTitle = path.posix.basename(normalizedPath, path.posix.extname(normalizedPath));
    const fallbackTitle = fileTitle
        .replace(/[-_]+/g, " ")
        .replace(/^./, (character) => character.toUpperCase());
    const taskMatches = [...parsed.content.matchAll(/^\s*[-*+]\s+\[([ xX])\]\s+/gm)];
    const complete = taskMatches.filter((match) => match[1].toLowerCase() === "x").length;
    return {
        path: normalizedPath,
        name: path.posix.basename(normalizedPath),
        title: heading || fallbackTitle,
        kind,
        content: parsed.content,
        metadata: parsed.data,
        modifiedAt,
        size,
        tasks: { complete, total: taskMatches.length },
    };
}
