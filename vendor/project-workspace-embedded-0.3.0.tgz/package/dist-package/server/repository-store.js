import { randomUUID } from "node:crypto";
import path from "node:path";
import { mkdir, readFile, rm, writeFile } from "node:fs/promises";
import { CredentialStore } from "./credential-store.js";
import { GitHubApiError, GitHubClient, parseGitHubUrl } from "./github-client.js";
import { buildFileTree, isPreviewableDocument, normalizeRepositoryPath, parseDocument, RepositoryFileError, } from "./repository-files.js";
const MAX_ASSET_BYTES = 10 * 1024 * 1024;
const MAX_DOCUMENT_BYTES = 2 * 1024 * 1024;
export class RepositoryStore {
    dataFile;
    snapshotDirectory;
    blobDirectory;
    github = new GitHubClient();
    credentials;
    repositories = [];
    snapshots = new Map();
    documents = new Map();
    syncs = new Map();
    constructor(dataDirectory = process.env.PROJECT_WORKSPACE_DATA_DIR || path.join(process.cwd(), ".data")) {
        const root = path.resolve(dataDirectory);
        const cacheDirectory = path.join(root, "api-cache");
        this.dataFile = path.join(root, "repositories.json");
        this.snapshotDirectory = path.join(cacheDirectory, "snapshots");
        this.blobDirectory = path.join(cacheDirectory, "blobs");
        this.credentials = new CredentialStore(root);
    }
    async initialize() {
        await Promise.all([
            this.credentials.initialize(),
            mkdir(this.snapshotDirectory, { recursive: true }),
            mkdir(this.blobDirectory, { recursive: true }),
        ]);
        try {
            const source = await readFile(this.dataFile, "utf8");
            const value = JSON.parse(source);
            const stored = Array.isArray(value) ? value.filter(isStoredRepository) : [];
            this.repositories = stored.flatMap((repository) => {
                try {
                    const location = parseGitHubUrl(repository.sourceUrl);
                    const defaultBranch = repository.defaultBranch || "";
                    const requestedTreeParts = location.requestedTreeParts || [];
                    return [{
                            id: repository.id,
                            name: repository.name,
                            sourceUrl: location.sourceUrl,
                            owner: repository.owner || location.owner,
                            repositoryName: repository.repositoryName || location.repositoryName,
                            defaultBranch,
                            ref: repository.ref || requestedTreeParts[0] || defaultBranch,
                            scopePath: repository.scopePath ?? requestedTreeParts.slice(1).join("/"),
                            commitSha: repository.commitSha || "",
                            committedAt: repository.committedAt || repository.lastSyncedAt,
                            addedAt: repository.addedAt,
                            lastSyncedAt: repository.lastSyncedAt,
                        }];
                }
                catch {
                    return [];
                }
            });
            const needsMigration = stored.some((repository) => typeof repository.ref !== "string" || typeof repository.scopePath !== "string");
            if (!Array.isArray(value) || stored.length !== value.length || needsMigration)
                await this.persist();
        }
        catch (error) {
            const code = error.code;
            if (code !== "ENOENT")
                throw error;
            await this.persist();
        }
        await Promise.all(this.repositories.map((repository) => this.loadSnapshot(repository)));
        await Promise.allSettled(this.repositories.map((repository) => this.sync(repository.id)));
    }
    list() {
        return [...this.repositories];
    }
    get(id) {
        return this.repositories.find((repository) => repository.id === id);
    }
    findAllByFullName(fullName) {
        const normalized = fullName.toLowerCase();
        return this.repositories.filter((repository) => `${repository.owner}/${repository.repositoryName}`.toLowerCase() === normalized);
    }
    summaries() {
        return this.repositories.map((repository) => {
            const snapshot = this.snapshots.get(repository.id);
            return {
                ...repository,
                fileCount: snapshot?.tree.fileCount || 0,
                available: Boolean(snapshot),
                authenticated: this.credentials.has(repository.id) || this.github.hasDefaultAuthentication(),
            };
        });
    }
    async add(gitHubUrl, requestedName, accessToken) {
        const location = parseGitHubUrl(gitHubUrl);
        const existing = this.repositories.find((repository) => repository.sourceUrl === location.sourceUrl);
        if (existing) {
            return this.updateCredential(existing.id, accessToken);
        }
        const info = await this.github.repository(location, accessToken);
        const resolved = await this.resolveSource(info, location.requestedTreeParts, accessToken);
        const now = new Date().toISOString();
        const repository = {
            id: randomUUID(),
            name: requestedName?.trim() || this.defaultDisplayName(info.repositoryName, resolved.scopePath),
            sourceUrl: this.sourceUrl(info, resolved.ref, resolved.scopePath),
            owner: info.owner,
            repositoryName: info.repositoryName,
            defaultBranch: info.defaultBranch,
            ref: resolved.ref,
            scopePath: resolved.scopePath,
            commitSha: resolved.commit.sha,
            committedAt: resolved.commit.committedAt,
            addedAt: now,
            lastSyncedAt: now,
        };
        this.repositories.push(repository);
        await this.setSnapshot(repository, resolved.files);
        await this.credentials.set(repository.id, accessToken);
        await this.persist();
        return repository;
    }
    async updateCredential(id, accessToken) {
        const repository = this.requireRepository(id);
        const info = await this.github.repository(repository, accessToken);
        const ref = repository.ref || info.defaultBranch;
        const commit = await this.github.commit(info, ref, accessToken);
        const changed = commit.sha !== repository.commitSha || !this.snapshots.has(id);
        let files;
        if (changed) {
            const repositoryFiles = await this.github.tree(info, commit.sha, accessToken);
            files = this.filesWithinScope(repositoryFiles, repository.scopePath);
            this.requireScopeContent(repository.scopePath, files);
        }
        await this.credentials.set(id, accessToken);
        repository.sourceUrl = this.sourceUrl(info, ref, repository.scopePath);
        repository.owner = info.owner;
        repository.repositoryName = info.repositoryName;
        repository.defaultBranch = info.defaultBranch;
        repository.ref = ref;
        repository.commitSha = commit.sha;
        repository.committedAt = commit.committedAt;
        repository.lastSyncedAt = new Date().toISOString();
        if (files) {
            await this.setSnapshot(repository, files);
            this.clearDocumentCache(id);
        }
        await this.persist();
        return repository;
    }
    sync(id) {
        const current = this.syncs.get(id);
        if (current)
            return current;
        const operation = this.performSync(id).finally(() => this.syncs.delete(id));
        this.syncs.set(id, operation);
        return operation;
    }
    async remove(id) {
        const nextRepositories = this.repositories.filter((repository) => repository.id !== id);
        if (nextRepositories.length === this.repositories.length)
            return false;
        this.repositories = nextRepositories;
        this.snapshots.delete(id);
        this.clearDocumentCache(id);
        await Promise.all([
            rm(this.snapshotPath(id), { force: true }),
            this.credentials.remove(id),
        ]);
        await this.persist();
        return true;
    }
    async files(id) {
        const snapshot = await this.requireSnapshot(id);
        return snapshot.tree;
    }
    async document(id, requestedPath) {
        const repository = this.requireRepository(id);
        const snapshot = await this.requireSnapshot(id);
        const relativePath = normalizeRepositoryPath(requestedPath);
        if (!isPreviewableDocument(relativePath)) {
            throw new RepositoryFileError("Only Markdown and Mermaid documents can be previewed.", 400);
        }
        const file = snapshot.filesByPath.get(relativePath);
        if (!file)
            throw new RepositoryFileError("Document not found.", 404);
        if (file.size > MAX_DOCUMENT_BYTES) {
            throw new RepositoryFileError("This document is larger than the 2 MB preview limit.", 413);
        }
        const cacheKey = `${id}:${snapshot.commitSha}:${file.sha}`;
        const cached = this.documents.get(cacheKey);
        if (cached)
            return cached;
        const source = (await this.readBlob(repository, file)).toString("utf8");
        const document = parseDocument(relativePath, source, repository.committedAt, file.size);
        this.documents.set(cacheKey, document);
        return document;
    }
    async asset(id, requestedPath) {
        const repository = this.requireRepository(id);
        const snapshot = await this.requireSnapshot(id);
        const relativePath = normalizeRepositoryPath(requestedPath);
        const file = snapshot.filesByPath.get(relativePath);
        if (!file)
            throw new RepositoryFileError("Asset not found.", 404);
        if (file.size > MAX_ASSET_BYTES) {
            throw new RepositoryFileError("This asset is larger than the 10 MB preview limit.", 413);
        }
        return {
            path: relativePath,
            sha: file.sha,
            content: await this.readBlob(repository, file),
        };
    }
    async performSync(id) {
        const repository = this.requireRepository(id);
        const accessToken = this.credentials.get(id);
        const info = repository.defaultBranch
            ? repository
            : await this.github.repository(repository, accessToken);
        const ref = repository.ref || info.defaultBranch;
        const commit = await this.github.commit(info, ref, accessToken);
        const changed = commit.sha !== repository.commitSha || !this.snapshots.has(id);
        repository.sourceUrl = this.sourceUrl(info, ref, repository.scopePath);
        repository.owner = info.owner;
        repository.repositoryName = info.repositoryName;
        repository.defaultBranch = info.defaultBranch;
        repository.ref = ref;
        repository.lastSyncedAt = new Date().toISOString();
        if (changed) {
            const repositoryFiles = await this.github.tree(info, commit.sha, accessToken);
            const files = this.filesWithinScope(repositoryFiles, repository.scopePath);
            this.requireScopeContent(repository.scopePath, files);
            repository.commitSha = commit.sha;
            repository.committedAt = commit.committedAt;
            await this.setSnapshot(repository, files);
            this.clearDocumentCache(id);
        }
        await this.persist();
        return { repository, changed };
    }
    async resolveSource(info, requestedTreeParts, accessToken) {
        if (!requestedTreeParts) {
            const commit = await this.github.commit(info, info.defaultBranch, accessToken);
            const files = await this.github.tree(info, commit.sha, accessToken);
            return { ref: info.defaultBranch, scopePath: "", commit, files };
        }
        const candidates = [];
        const seen = new Set();
        const addCandidate = (splitAt) => {
            const candidate = {
                ref: requestedTreeParts.slice(0, splitAt).join("/"),
                scopePath: requestedTreeParts.slice(splitAt).join("/"),
            };
            const key = `${candidate.ref}\0${candidate.scopePath}`;
            if (!seen.has(key)) {
                seen.add(key);
                candidates.push(candidate);
            }
        };
        for (let splitAt = 1; splitAt <= requestedTreeParts.length; splitAt += 1) {
            if (requestedTreeParts.slice(0, splitAt).join("/") === info.defaultBranch) {
                addCandidate(splitAt);
                break;
            }
        }
        for (let splitAt = requestedTreeParts.length; splitAt >= 1; splitAt -= 1) {
            addCandidate(splitAt);
        }
        for (const candidate of candidates) {
            try {
                const commit = await this.github.commit(info, candidate.ref, accessToken);
                const repositoryFiles = await this.github.tree(info, commit.sha, accessToken);
                const files = this.filesWithinScope(repositoryFiles, candidate.scopePath);
                if (candidate.scopePath && files.length === 0)
                    continue;
                return { ...candidate, commit, files };
            }
            catch (error) {
                if (!(error instanceof GitHubApiError) || error.statusCode !== 404)
                    throw error;
            }
        }
        throw new GitHubApiError("GitHub branch or folder not found. Copy the folder URL directly from GitHub and try again.", 404);
    }
    filesWithinScope(files, scopePath) {
        if (!scopePath)
            return files;
        const normalizedScope = normalizeRepositoryPath(scopePath);
        const prefix = `${normalizedScope}/`;
        return files
            .filter((file) => file.path.startsWith(prefix))
            .map((file) => ({ ...file, path: file.path.slice(prefix.length) }));
    }
    requireScopeContent(scopePath, files) {
        if (scopePath && files.length === 0) {
            throw new GitHubApiError(`The GitHub folder “${scopePath}” no longer exists on the selected branch.`, 404);
        }
    }
    sourceUrl(info, ref, scopePath) {
        const root = `https://github.com/${info.owner}/${info.repositoryName}`;
        if (!scopePath && ref === info.defaultBranch)
            return root;
        const treePath = [...ref.split("/"), ...scopePath.split("/").filter(Boolean)]
            .map(encodeURIComponent)
            .join("/");
        return `${root}/tree/${treePath}`;
    }
    defaultDisplayName(repositoryName, scopePath) {
        return scopePath ? `${repositoryName} / ${scopePath}` : repositoryName;
    }
    async setSnapshot(repository, files) {
        this.snapshots.set(repository.id, {
            commitSha: repository.commitSha,
            files,
            filesByPath: new Map(files.map((file) => [file.path, file])),
            tree: buildFileTree(files, repository.committedAt),
        });
        await writeFile(this.snapshotPath(repository.id), `${JSON.stringify({ commitSha: repository.commitSha, files })}\n`, "utf8");
    }
    async loadSnapshot(repository) {
        try {
            const source = await readFile(this.snapshotPath(repository.id), "utf8");
            const value = JSON.parse(source);
            if (value.commitSha !== repository.commitSha || !Array.isArray(value.files))
                return;
            const files = value.files.filter(isRepositoryFile);
            if (files.length !== value.files.length)
                return;
            this.snapshots.set(repository.id, {
                commitSha: repository.commitSha,
                files,
                filesByPath: new Map(files.map((file) => [file.path, file])),
                tree: buildFileTree(files, repository.committedAt),
            });
        }
        catch (error) {
            if (error.code !== "ENOENT")
                console.warn(`Ignoring invalid cache for ${repository.name}.`);
        }
    }
    async readBlob(repository, file) {
        const cachePath = this.blobPath(file.sha);
        try {
            return await readFile(cachePath);
        }
        catch (error) {
            if (error.code !== "ENOENT")
                throw error;
        }
        const content = await this.github.blob(repository, file.sha, this.credentials.get(repository.id));
        await writeFile(cachePath, content);
        return content;
    }
    snapshotPath(id) {
        return path.join(this.snapshotDirectory, `${id}.json`);
    }
    blobPath(sha) {
        if (!/^[A-Za-z0-9_-]{1,100}$/.test(sha)) {
            throw new RepositoryFileError("GitHub returned an invalid file identifier.", 502);
        }
        return path.join(this.blobDirectory, sha);
    }
    requireRepository(id) {
        const repository = this.get(id);
        if (!repository)
            throw new GitHubApiError("Repository not found.", 404);
        return repository;
    }
    async requireSnapshot(id) {
        const existing = this.snapshots.get(id);
        if (existing)
            return existing;
        await this.sync(id);
        const snapshot = this.snapshots.get(id);
        if (!snapshot)
            throw new GitHubApiError("Repository content is currently unavailable.", 503);
        return snapshot;
    }
    clearDocumentCache(id) {
        for (const key of this.documents.keys())
            if (key.startsWith(`${id}:`))
                this.documents.delete(key);
    }
    async persist() {
        const stored = this.repositories.map((repository) => ({ ...repository }));
        await writeFile(this.dataFile, `${JSON.stringify(stored, null, 2)}\n`, "utf8");
    }
}
function isRepositoryFile(value) {
    if (!value || typeof value !== "object")
        return false;
    const file = value;
    return (typeof file.path === "string" &&
        typeof file.sha === "string" &&
        typeof file.size === "number" &&
        Number.isFinite(file.size) &&
        file.size >= 0);
}
function isStoredRepository(value) {
    if (!value || typeof value !== "object")
        return false;
    const repository = value;
    return (typeof repository.id === "string" &&
        /^[0-9a-f-]{36}$/i.test(repository.id) &&
        typeof repository.name === "string" &&
        typeof repository.sourceUrl === "string" &&
        typeof repository.addedAt === "string" &&
        typeof repository.lastSyncedAt === "string");
}
