export interface Repository {
    id: string;
    name: string;
    sourceUrl: string;
    owner: string;
    repositoryName: string;
    defaultBranch: string;
    ref: string;
    scopePath: string;
    commitSha: string;
    committedAt: string;
    addedAt: string;
    lastSyncedAt: string;
}
export interface RepositorySummary extends Repository {
    fileCount: number;
    available: boolean;
    authenticated: boolean;
}
export interface RepositoryFile {
    path: string;
    sha: string;
    size: number;
}
export interface FileNode {
    name: string;
    path: string;
    type: "directory" | "file";
    children?: FileNode[];
    isReadme?: boolean;
    kind?: "markdown" | "mermaid";
    modifiedAt?: string;
    size?: number;
}
export interface DocumentPayload {
    path: string;
    name: string;
    title: string;
    kind: "markdown" | "mermaid";
    content: string;
    metadata: Record<string, unknown>;
    modifiedAt: string;
    size: number;
    tasks: {
        complete: number;
        total: number;
    };
}
