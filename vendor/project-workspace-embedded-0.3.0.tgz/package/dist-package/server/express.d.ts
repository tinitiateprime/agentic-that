import { type Request as ExpressRequest } from "express";
import { type ProjectWorkspaceHandlerOptions, type ProjectWorkspaceIdentity } from "./embedded.js";
export interface ProjectWorkspaceExpressOptions extends Omit<ProjectWorkspaceHandlerOptions, "getIdentity"> {
    /** Read the identity already verified by the host's Express login middleware. */
    getIdentity: (request: ExpressRequest) => ProjectWorkspaceIdentity | null | Promise<ProjectWorkspaceIdentity | null>;
}
/** Mount at the same apiBasePath given to ProjectWorkspacePage. */
export declare function createProjectWorkspaceExpressRouter(options: ProjectWorkspaceExpressOptions): import("express-serve-static-core").Router;
