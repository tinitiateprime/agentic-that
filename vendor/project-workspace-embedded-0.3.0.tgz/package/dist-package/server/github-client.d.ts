export interface GitHubLocation {
    owner: string;
    repositoryName: string;
    sourceUrl: string;
    requestedTreeParts?: string[];
}
export interface GitHubRepositoryInfo extends GitHubLocation {
    defaultBranch: string;
    private: boolean;
}
export interface GitHubCommit {
    sha: string;
    committedAt: string;
}
export interface GitHubTreeFile {
    path: string;
    sha: string;
    size: number;
}
export declare class GitHubApiError extends Error {
    statusCode: number;
    constructor(message: string, statusCode: number);
}
export declare function parseGitHubUrl(value: string): GitHubLocation;
export declare class GitHubClient {
    private readonly apiUrl;
    private readonly token;
    private readonly appId;
    private readonly appPrivateKey;
    private installationIds;
    private installationTokens;
    private rateLimitedUntil;
    hasDefaultAuthentication(): boolean;
    repository(location: GitHubLocation, accessToken?: string): Promise<GitHubRepositoryInfo>;
    commit(location: GitHubLocation, ref: string, accessToken?: string): Promise<GitHubCommit>;
    tree(location: GitHubLocation, commitSha: string, accessToken?: string): Promise<GitHubTreeFile[]>;
    blob(location: GitHubLocation, sha: string, accessToken?: string): Promise<Buffer>;
    private walkTree;
    private filesFromEntries;
    private repositoryRequest;
    private repositoryAuthorization;
    private appInstallationToken;
    private appJwt;
    private request;
    private rateLimitMessage;
    private rateLimitKey;
}
