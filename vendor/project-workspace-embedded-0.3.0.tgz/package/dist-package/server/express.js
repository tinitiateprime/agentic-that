import { Readable } from "node:stream";
import express from "express";
import { createProjectWorkspaceHandler, } from "./embedded.js";
/** Mount at the same apiBasePath given to ProjectWorkspacePage. */
export function createProjectWorkspaceExpressRouter(options) {
    const router = express.Router();
    const identities = new WeakMap();
    const rawBodies = new WeakMap();
    const requestBytes = (source) => {
        const bytes = new Uint8Array(new ArrayBuffer(source.byteLength));
        bytes.set(source);
        return bytes;
    };
    const handler = createProjectWorkspaceHandler({
        ...options,
        getIdentity: (request) => identities.get(request) || null,
    });
    router.use(express.json({
        limit: "1mb",
        verify(request, _response, body) {
            rawBodies.set(request, Buffer.from(body));
        },
    }));
    router.use((request, response, next) => {
        void (async () => {
            const identity = await options.getIdentity(request);
            const headers = new Headers();
            for (const [key, value] of Object.entries(request.headers)) {
                if (Array.isArray(value))
                    value.forEach((item) => headers.append(key, item));
                else if (value !== undefined)
                    headers.set(key, value);
            }
            headers.delete("content-length");
            const method = request.method.toUpperCase();
            const rawBody = rawBodies.get(request) || request.rawBody;
            if (request.path === "/github/webhook" && !rawBody) {
                response.status(400).json({
                    message: "The raw webhook body is unavailable. Mount the Project Workspace router before other JSON parsers.",
                });
                return;
            }
            let body;
            if (!["GET", "HEAD"].includes(method)) {
                if (rawBody)
                    body = requestBytes(rawBody);
                else if (Buffer.isBuffer(request.body))
                    body = requestBytes(request.body);
                else if (typeof request.body === "string")
                    body = request.body;
                else if (request.body !== undefined)
                    body = JSON.stringify(request.body);
            }
            const abort = new AbortController();
            const host = request.get("host");
            if (!host)
                throw new Error("The host request is missing its Host header.");
            const webRequest = new Request(`${request.protocol}://${host}${request.originalUrl}`, { method, headers, body, signal: abort.signal });
            identities.set(webRequest, identity);
            response.once("close", () => abort.abort());
            const result = await handler(webRequest);
            response.status(result.status);
            result.headers.forEach((value, key) => response.setHeader(key, value));
            if (!result.body) {
                response.end();
                return;
            }
            const stream = Readable.fromWeb(result.body);
            stream.once("error", next);
            response.once("close", () => stream.destroy());
            stream.pipe(response);
        })().catch(next);
    });
    return router;
}
