import type { DocumentPayload, FileNode, RepositoryFile } from "./types.js";
export declare class RepositoryFileError extends Error {
    statusCode: number;
    constructor(message: string, statusCode: number);
}
export declare function isMarkdown(fileName: string): boolean;
export declare function isMermaid(fileName: string): boolean;
export declare function isPreviewableDocument(fileName: string): boolean;
export declare function normalizeRepositoryPath(value: string): string;
export declare function buildFileTree(files: RepositoryFile[], modifiedAt: string): {
    nodes: FileNode[];
    fileCount: number;
};
export declare function parseDocument(relativePath: string, source: string, modifiedAt: string, size?: number): DocumentPayload;
