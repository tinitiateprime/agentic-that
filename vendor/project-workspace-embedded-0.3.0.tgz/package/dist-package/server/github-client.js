import { createHash, createSign } from "node:crypto";
const API_VERSION = "2022-11-28";
const REQUEST_TIMEOUT_MS = 30_000;
const MAX_TREE_ENTRIES = 100_000;
export class GitHubApiError extends Error {
    statusCode;
    constructor(message, statusCode) {
        super(message);
        this.statusCode = statusCode;
    }
}
export function parseGitHubUrl(value) {
    const input = value.trim();
    let url;
    try {
        url = new URL(input);
    }
    catch {
        throw new GitHubApiError("Enter a valid GitHub repository URL.", 400);
    }
    if (url.protocol !== "https:" || !["github.com", "www.github.com"].includes(url.hostname.toLowerCase())) {
        throw new GitHubApiError("Only HTTPS GitHub repository URLs are supported.", 400);
    }
    if (url.username || url.password || url.search || url.hash) {
        throw new GitHubApiError("Enter the clean GitHub repository URL without credentials or query parameters.", 400);
    }
    let parts;
    try {
        parts = decodeURIComponent(url.pathname).split("/").filter(Boolean);
    }
    catch {
        throw new GitHubApiError("The GitHub URL contains invalid encoded characters.", 400);
    }
    if (parts.length < 2) {
        throw new GitHubApiError("Use a GitHub repository or repository folder URL.", 400);
    }
    const owner = parts[0];
    const repositoryName = parts[1].replace(/\.git$/i, "");
    if (!/^[A-Za-z0-9_.-]+$/.test(owner) || !/^[A-Za-z0-9_.-]+$/.test(repositoryName)) {
        throw new GitHubApiError("Enter a valid GitHub repository URL.", 400);
    }
    let requestedTreeParts;
    if (parts.length > 2) {
        if (parts[2] !== "tree" || parts.length < 4) {
            throw new GitHubApiError("Use a repository URL or a folder URL such as https://github.com/company/project/tree/main/docs.", 400);
        }
        requestedTreeParts = parts.slice(3);
        if (requestedTreeParts.some((part) => !part || part === "." || part === ".." || part.includes("\\") || part.includes("\0"))) {
            throw new GitHubApiError("The GitHub folder URL contains an invalid path.", 400);
        }
    }
    const rootUrl = `https://github.com/${owner}/${repositoryName}`;
    const sourceUrl = requestedTreeParts
        ? `${rootUrl}/tree/${requestedTreeParts.map(encodeURIComponent).join("/")}`
        : rootUrl;
    return {
        owner,
        repositoryName,
        sourceUrl,
        requestedTreeParts,
    };
}
export class GitHubClient {
    apiUrl = (process.env.GITHUB_API_URL || "https://api.github.com").replace(/\/$/, "");
    token = process.env.GITHUB_TOKEN?.trim();
    appId = process.env.GITHUB_APP_ID?.trim();
    appPrivateKey = process.env.GITHUB_APP_PRIVATE_KEY?.replace(/\\n/g, "\n").trim();
    installationIds = new Map();
    installationTokens = new Map();
    rateLimitedUntil = new Map();
    hasDefaultAuthentication() {
        return Boolean(this.token || (this.appId && this.appPrivateKey));
    }
    async repository(location, accessToken) {
        const result = await this.repositoryRequest(location, `/repos/${encodeURIComponent(location.owner)}/${encodeURIComponent(location.repositoryName)}`, accessToken);
        if (!result.default_branch) {
            throw new GitHubApiError("This repository has no default branch or committed files yet.", 422);
        }
        return {
            owner: result.owner.login,
            repositoryName: result.name,
            sourceUrl: result.html_url,
            defaultBranch: result.default_branch,
            private: result.private,
        };
    }
    async commit(location, ref, accessToken) {
        const result = await this.repositoryRequest(location, `/repos/${encodeURIComponent(location.owner)}/${encodeURIComponent(location.repositoryName)}/commits/${encodeURIComponent(ref)}`, accessToken);
        return {
            sha: result.sha,
            committedAt: result.commit?.committer?.date || result.commit?.author?.date || new Date().toISOString(),
        };
    }
    async tree(location, commitSha, accessToken) {
        const recursive = await this.repositoryRequest(location, `/repos/${encodeURIComponent(location.owner)}/${encodeURIComponent(location.repositoryName)}/git/trees/${encodeURIComponent(commitSha)}?recursive=1`, accessToken);
        if (!recursive.truncated)
            return this.filesFromEntries(recursive.tree);
        return this.walkTree(location, commitSha, accessToken);
    }
    async blob(location, sha, accessToken) {
        const result = await this.repositoryRequest(location, `/repos/${encodeURIComponent(location.owner)}/${encodeURIComponent(location.repositoryName)}/git/blobs/${encodeURIComponent(sha)}`, accessToken);
        if (result.encoding !== "base64") {
            throw new GitHubApiError("GitHub returned an unsupported file encoding.", 502);
        }
        return Buffer.from(result.content.replace(/\s/g, ""), "base64");
    }
    async walkTree(location, rootSha, accessToken) {
        const files = [];
        const queue = [{ sha: rootSha, prefix: "" }];
        let seenEntries = 0;
        while (queue.length > 0) {
            const current = queue.shift();
            if (!current)
                break;
            const result = await this.repositoryRequest(location, `/repos/${encodeURIComponent(location.owner)}/${encodeURIComponent(location.repositoryName)}/git/trees/${encodeURIComponent(current.sha)}`, accessToken);
            for (const entry of result.tree) {
                seenEntries += 1;
                if (seenEntries > MAX_TREE_ENTRIES) {
                    throw new GitHubApiError("This repository is too large to preview safely.", 413);
                }
                const entryPath = current.prefix ? `${current.prefix}/${entry.path}` : entry.path;
                if (entry.type === "tree")
                    queue.push({ sha: entry.sha, prefix: entryPath });
                if (entry.type === "blob") {
                    files.push({ path: entryPath, sha: entry.sha, size: entry.size || 0 });
                }
            }
        }
        return files;
    }
    filesFromEntries(entries) {
        if (entries.length > MAX_TREE_ENTRIES) {
            throw new GitHubApiError("This repository is too large to preview safely.", 413);
        }
        return entries
            .filter((entry) => entry.type === "blob")
            .map((entry) => ({ path: entry.path, sha: entry.sha, size: entry.size || 0 }));
    }
    async repositoryRequest(location, path, accessToken) {
        const authorization = accessToken || await this.repositoryAuthorization(location);
        return this.request(path, authorization);
    }
    async repositoryAuthorization(location) {
        if (this.appId && this.appPrivateKey) {
            try {
                return await this.appInstallationToken(location);
            }
            catch (error) {
                if (!(error instanceof GitHubApiError) || error.statusCode !== 404)
                    throw error;
            }
        }
        return this.token;
    }
    async appInstallationToken(location) {
        const key = `${location.owner}/${location.repositoryName}`.toLowerCase();
        let installationId = this.installationIds.get(key);
        if (!installationId) {
            const installation = await this.request(`/repos/${encodeURIComponent(location.owner)}/${encodeURIComponent(location.repositoryName)}/installation`, this.appJwt());
            installationId = installation.id;
            this.installationIds.set(key, installationId);
        }
        const cached = this.installationTokens.get(installationId);
        if (cached && cached.expiresAt > Date.now() + 5 * 60_000)
            return cached.token;
        const token = await this.request(`/app/installations/${installationId}/access_tokens`, this.appJwt(), { method: "POST" });
        this.installationTokens.set(installationId, {
            token: token.token,
            expiresAt: new Date(token.expires_at).getTime(),
        });
        return token.token;
    }
    appJwt() {
        if (!this.appId || !this.appPrivateKey) {
            throw new GitHubApiError("GitHub App credentials are incomplete.", 500);
        }
        const now = Math.floor(Date.now() / 1000);
        const encode = (value) => Buffer.from(JSON.stringify(value)).toString("base64url");
        const unsigned = `${encode({ alg: "RS256", typ: "JWT" })}.${encode({ iat: now - 60, exp: now + 540, iss: this.appId })}`;
        const signer = createSign("RSA-SHA256");
        signer.update(unsigned);
        signer.end();
        return `${unsigned}.${signer.sign(this.appPrivateKey).toString("base64url")}`;
    }
    async request(path, token, init = {}) {
        const rateLimitKey = this.rateLimitKey(token);
        const limitedUntil = this.rateLimitedUntil.get(rateLimitKey) || 0;
        if (Date.now() < limitedUntil) {
            throw new GitHubApiError(this.rateLimitMessage(limitedUntil), 429);
        }
        const headers = new Headers(init.headers);
        headers.set("Accept", "application/vnd.github+json");
        headers.set("User-Agent", "Project-Workspace-Service");
        headers.set("X-GitHub-Api-Version", API_VERSION);
        if (token)
            headers.set("Authorization", `Bearer ${token}`);
        let response;
        try {
            response = await fetch(`${this.apiUrl}${path}`, {
                ...init,
                headers,
                signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
            });
        }
        catch (error) {
            if (error instanceof Error && error.name === "TimeoutError") {
                throw new GitHubApiError("GitHub did not respond in time. Please try again.", 504);
            }
            throw new GitHubApiError("Could not connect to GitHub. Please try again.", 502);
        }
        const text = await response.text();
        let payload = {};
        if (text) {
            try {
                payload = JSON.parse(text);
            }
            catch {
                payload = {};
            }
        }
        if (!response.ok) {
            const remaining = response.headers.get("x-ratelimit-remaining");
            const rateLimited = response.status === 429 ||
                (response.status === 403 && (remaining === "0" || /(?:secondary )?rate limit/i.test(payload.message || "")));
            if (rateLimited) {
                const retryAfter = response.headers.get("retry-after");
                const reset = response.headers.get("x-ratelimit-reset");
                const retryAfterSeconds = retryAfter === null ? Number.NaN : Number(retryAfter);
                const resetSeconds = reset === null ? Number.NaN : Number(reset);
                const resetAt = Number.isFinite(retryAfterSeconds)
                    ? Date.now() + retryAfterSeconds * 1_000
                    : Number.isFinite(resetSeconds)
                        ? resetSeconds * 1_000
                        : Date.now() + 60_000;
                this.rateLimitedUntil.set(rateLimitKey, resetAt);
                throw new GitHubApiError(this.rateLimitMessage(resetAt), 429);
            }
            if (response.status === 404) {
                throw new GitHubApiError("Repository not found or this token cannot access it. Check the URL and the token's repository access.", 404);
            }
            if (response.status === 401 || response.status === 403) {
                throw new GitHubApiError("GitHub authentication does not have read access to this repository.", 403);
            }
            throw new GitHubApiError(payload.message || `GitHub request failed (${response.status}).`, 502);
        }
        return payload;
    }
    rateLimitMessage(resetAt) {
        const resetTime = new Intl.DateTimeFormat("en", {
            hour: "numeric",
            minute: "2-digit",
            timeZoneName: "short",
        }).format(new Date(resetAt));
        return `GitHub API limit reached for this credential; synchronization will resume after ${resetTime}. You can update the repository access token if needed.`;
    }
    rateLimitKey(token) {
        return token
            ? createHash("sha256").update(token).digest("hex")
            : "anonymous";
    }
}
